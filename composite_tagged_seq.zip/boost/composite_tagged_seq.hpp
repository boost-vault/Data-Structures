#ifndef BOOST_COMPOSITE_TAGGED_SEQ_INCLUDED//if#BOOST_COMPOSITE_TAGGED_SEQ_INCLUDED
#define BOOST_COMPOSITE_TAGGED_SEQ_INCLUDED
//  (C) Copyright Larry Evans 2009.
//
//  Permission to copy, use, modify, sell and distribute this software
//  is granted provided this copyright notice appears in all copies.
//  This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.
//
//ChangeLog:
//  2009-12-08.1330 CST
//    WHAT:
//      cp'ed from variadic_templates/boost/composite_tagged.hpp
//    WHY:
//      To modify for use with non-variadic template compilers.
//

#include <cstddef>


#ifdef COMPATIBLE_ALIGNMENT_IS_LCM
  #include <boost/math/common_factor_ct.hpp>
#endif
#include <boost/aligned_storage.hpp>
#include <boost/mpl/for_each.hpp>
#include <boost/mpl/range_c.hpp>
#include <boost/mpl/next_prior.hpp>
#include <boost/mpl/at.hpp>

#include <boost/mpl/fold.hpp>

#include <boost/fusion/support/pair.hpp>

#include <boost/assert.hpp>

//[switch #includes
//  These are from:
//
//    http://svn.boost.org/svn/boost/sandbox/switch/
//
  #include <boost/control/switch.hpp>
  #include <boost/control/case.hpp>
//]switch #includes

namespace boost
{
namespace composite_tags
{
    struct one_of_maybe
      //composite contains an instance of 'one of' template arguments, *maybe*.
      //This composite is like haskell's Maybe except there's more than one
      //optional value.
      ; 
    struct all_of_aligned 
      //composite contains instances of 'all of' template arguments, properly 'aligned'.
      ; 
    struct all_of_packed  
      //composite contains instances of 'all of' template arguments, 'packed' together.
      ; 

};

  template
  < class CompositeTag//possibly something from namespace composite_tags.
  , class Index0//index of 1st Component ( Some instantiation of mpl::integral_c ).
  , typename ComponentSeq//sequence of components
  >
  struct
composite_tagged_seq
;

namespace composite_components
{
    enum special_id
    { nothing_id //signifies error, something like haskell's Nothing.
    , empty_id //signifies empty class.
    };
    template<special_id Id>
    struct special_type
    {
            static
          special_type*
        _(void)
        {
            static special_type a;
            return &a;
        }
        special_type(void)
        {}
        special_type(special_type const&)
        {}
        void operator=(special_type const&)
        {}
        bool operator==(special_type const&)const
        {
            return true;
        }
    };
    typedef special_type<empty_id> empty;
    typedef special_type<nothing_id> nothing;
    
}

namespace detail_composite_tagged//general
{

  template
  < typename Index
  >
struct enum_base
;
  template
  < typename Type
  , Type Valu
  >
struct enum_base
  < mpl::integral_c<Type,Valu>
  >
{
        typedef
      int
    type
    ;
};  

  template
  < std::size_t Left
  , std::size_t Right
  >
  struct
compatible_alignment
/**@brief
 *  "Metafunction" returning alignment which is compatible with the 
 *   metafunction argument alignments, Left and Right.
 *
 *  The real reason why this template was created instead of directly using
 *  static_lcm was to provide the documentation shown below which justifies
 *  static_lcm use.
 */
{
        static
      std::size_t const
    value=
    #ifdef COMPATIBLE_ALIGNMENT_IS_LCM
      ::boost::math::static_lcm
      < (unsigned long)Left
      , (unsigned long)Right
      >::value
    #else
      Left>Right?Left:Right 
      //2010-03-11:
      //  this is what boost::variant does currently, 
      //  although there's a pending fix:
      //    https://svn.boost.org/trac/boost/ticket/993
      //
    #endif
      
      //The use of static_lcm is based on the statement:
      //
      //  N is the least common multiple of all Alignments
      //
      //in paragraph 1 on page 10 of:
      //
      //  http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2007/n2165.pdf
      //
      //AFAICT, the reason lcm is used instead of just taking the
      //maximum:
      //
      //  Left>Right?Left:Right
      //
      //is to account for "Extended alignments" mentioned in paragraph 3 
      //on page 3 of the n2165 reference mentioned above.  OTOH, if only
      //"Fundamental alignments" are used (which, I assume, are the
      //"static alignments;powers of 2" in paragraph 4 on page 5 of:
      //
      //  http://www.open-std.org/JTC1/SC22/WG21/docs/papers/2006/n2140.pdf
      //
      //) then simply using max instead of lcm would work.
    ;
};

  template
  < std::size_t Offset
  , std::size_t Alignment
  >
  struct
aligned_offset
{
        static
      std::size_t const
    remainder
    = Offset%Alignment
    ;
        static
      std::size_t const
    value
    = remainder == 0
    ? Offset
    : Offset+(Alignment-remainder)
    /**@brief
     * value is minimum value > Offset such that
     * value%Alignment == 0.
     *
     * This assures that if Offset0%Alignment ==0,
     * then (Offset0+value)%Alignment ==0.
     * Here, Offset0 represents the start location of
     * the whole composite.  This assumption that
     * Offset0%Alignment == 0 is assured by the
     * calculation of the whole composite's alignment
     * (given by calls to compatible_alignment within
     * the definition of:
     *
     *   layout_operators<Tag>push_back::type::align_part).
     *
     * where Tag is one of {one_of_maybe,all_of_aligned}.
     *
     */
    ;
    
};
        
  template
  < std::size_t Size
  , std::size_t Align
  >
  struct
aligned_char_storage
{
    aligned_char_storage( void)
    {}
    aligned_char_storage( aligned_char_storage const&)
    {}
      void
    operator=( aligned_char_storage const&)
    {}
      char const*
    address(void)const
    {
        void const*p=buffer.address();
        return static_cast<char const*>(p);
    }
      char*
    address(void)
    {
        void*p=buffer.address();
        return static_cast<char*>(p);
    }
 private:    
      ::boost::aligned_storage
      < Size
      , Align
      >
    buffer
    ;
};
  
  template
  < std::size_t Size
  , std::size_t Align
  >
  struct
aligned_sized_char_storage
{
    aligned_sized_char_storage( void)
    {}
    aligned_sized_char_storage( aligned_sized_char_storage const&)
    {}
      void
    operator=( aligned_sized_char_storage const&)
    {}
      char const*
    address(void)const
    {
        return buffer;
    }
      char*
    address(void)
    {
        return buffer;
    }
 private:    
    char buffer[Size]
    ;
};

  template
  < class CompositeTag
  >
  struct 
layout_operators
/**@brief
 *  Member templates:
 *    push_back
 *    layout0
 *  are used to calculate various "layout" traits of a composite.
 *  These traits include at least:
 *    the size and the index
 *  and possibly:
 *    the offsets and alignments
 *  of the composite's components.
 *  Also a layout contains inject and project
 *  functions for creating components of the composite
 *  in a memory buffer and retrieving the components
 *  from that memory buffer.
 */
{
      template
      < typename HeadLayout   //layout of some Composite
      , typename TailComponent//Type to be appended to some Composite
      >
      struct      
    push_back
    /**@brief
     *  Binary operator:
     *    Calculates the layout of composite with component, TailComponent,
     *    appended to a Composite with layout, HeadLayout, and return
     *    layout result in push_back<HeadLayout,TailComponent>::type.
     */
    ;
      template
      < typename IndexUndefined //index for accessing this layout.
      >
      struct
    layout0
    /**@brief
     *  Nullary operator:
     *    The layout of a composite with 0 components.
     */
    ;
};

  template
  < class CompositeTag
  , class Index0
  , typename ComponentSeq
  >
  struct 
layout_composite_seq
{
        typedef
      detail_composite_tagged::layout_operators<CompositeTag>
    layout_ops
    ;
        typedef
      typename Index0::value_type
    index_type
    ;
        typedef typename
      detail_composite_tagged::enum_base<Index0>::type
    index_base
    ;
        typedef
      mpl::integral_c<index_base,index_base(Index0::value)-1>
    index_undefined
    ;
        typedef
      typename mpl::fold
      < ComponentSeq
      , typename layout_ops::template layout0<index_undefined>
      , typename layout_ops::template push_back
        < mpl::arg<1>
        , mpl::arg<2>
        >
      >::type
    scanned
    ;
        typedef
      typename mpl::next<typename scanned::index_part>::type
    index_end
    ;
};

  template
  < std::size_t Size=0
  , std::size_t Alignment=1
  >
struct size_alignment_pair
{
        static
      std::size_t const
    size
    =Size
    ;
        static
      std::size_t const
    alignment
    =Alignment
    ;
        typedef
      size_alignment_pair
    type
    ;
};  
  template
  < typename T
  >
  struct
size_of
{
        static
      std::size_t const
    value
    =sizeof(T)
    ;
};
  template
  < typename T
  >
  struct
alignment_of
{
        static
      std::size_t const
    value
    =::boost::alignment_of<T>::value
    ;
};
  template
  <
  >
  struct
size_of
  < composite_components::empty
  >
{
        static
      std::size_t const
    value
    =0
    ;
};  
  template
  <
  >
  struct
alignment_of
  < composite_components::empty
  >
{
        static
      std::size_t const
    value
    =1
    ;
};  
  template
  < std::size_t Size
  , std::size_t Align
  >
  struct
alignment_of
  < aligned_sized_char_storage<Size,Align>
  >
{
        static
      std::size_t const
    value
    =Align
    ;
};  
  
}//exit detail_composite_tagged//general

#if 1 //if#composite_tags::all_of_packed
namespace  detail_composite_tagged//composite_tags::all_of_packed
{
  template
  <// class CompositeTag
  >
struct layout_operators< composite_tags::all_of_packed>
{

      template
      < std::size_t Size=0
      >
    struct component_layout
    {
            static
          std::size_t const
        size
        =Size
        ;
    };
      template
      < typename Component
      >
    struct layout_of
    : component_layout<size_of<Component>::value>
    {};
    
      template
      < typename HeadComposed
      , typename TailLayout
      >
      struct
    compose_layout
    {
            static
          std::size_t const
        offset
        =HeadComposed::size
        ;
            static
          std::size_t const
        size
        =HeadComposed::size
        +TailLayout::size
        ;
    };
        
      template
      < typename IndexUndefined
      >
      struct      
    layout0
    {
            typedef
          IndexUndefined
        index_part
        ;
            typedef
          component_layout<>
        comp_part
        ;
            static
          void
        inject(void)
        {
        }
            static
          void
        inject_default(void)
        {
        }
            static
          void
        project(void)
        {
        }

    };
      template
      < typename HeadLayout
      , typename TailComponent
      >
      struct      
    push_back
    {
          struct
        type
        : private HeadLayout
        {
                typedef
              HeadLayout
            head_layout
            ;
                typedef
              typename mpl::next<typename HeadLayout::index_part>::type
            index_part
            ;
                typedef
              compose_layout
              < typename HeadLayout::comp_part
              , layout_of<TailComponent>
              >
            comp_part
            ;
              using HeadLayout::
            inject
            ;
                static
              void
            inject
              ( index_part index_arg
              , char*buffer_composite
              , TailComponent const& tail_component
              )
            
            {
                void      * tail_buffer=buffer_composite+comp_part::offset;
                void const* tail_ptr=&tail_component;
                std::size_t const tail_size=sizeof(TailComponent);
                std::memcpy(tail_buffer, tail_ptr, tail_size);
            }
              using HeadLayout::
            inject_default
            ;
                static
              void
            inject_default
              ( index_part index_arg
              , char*buffer_composite
              )
            
            {
                TailComponent tail_component;
                inject(index_arg,buffer_composite,tail_component);
            }
              using HeadLayout::
            project
            ;
                static
              void
            project(index_part index_arg, char const*buffer_composite, TailComponent& tail_component)
            {
                void const* tail_buffer=buffer_composite+comp_part::offset;
                void      * tail_ptr=&tail_component;
                std::size_t const tail_size=sizeof(TailComponent);
                std::memcpy(tail_ptr, tail_buffer, tail_size);
            }
            
        };//end type struct
    };//end push_back struct
};//end layout_operators struct


namespace detail_all_of
{  
  template
  < typename Layout
  , typename IndexBegin
  >
  struct
methods_all
{
        typedef
      IndexBegin
    index_begin
    ;
        typedef
      typename mpl::next<typename Layout::index_part>::type
    index_end
    ;
        typedef typename
      enum_base<IndexBegin>::type
    index_type
    ;
        typedef typename
      mpl::range_c
      < index_type
      , index_begin::value
      , index_end::value
      >::type
    indices
    ;
      struct
    ctor_default_one
    {

          char*
        my_buffer
        ;
        ctor_default_one(char* a_buffer)
        : my_buffer(a_buffer)
        {}
          template
          < class Index
          >
          void
        operator()(Index index)const
        {
            Layout::inject_default(index,my_buffer);
        }
         
    };
        static
      void
    ctor_default_all(char*buffer)
    //Call default construct for all components.
    {
        ctor_default_one constructor(buffer);
        mpl::for_each<indices>(constructor);
    };
      template
      < typename FrBuffer
      >
      struct
    ctor_copy_one
    {

          char*
        my_to_buffer
        ;
          char const*
        my_fr_buffer
        ;
        ctor_copy_one(char* a_to_buffer, FrBuffer* a_fr_buffer)
        : my_to_buffer(a_to_buffer)
        , my_fr_buffer(a_fr_buffer)
        {}
          template
          < class Index
          >
          void
        operator()(Index index)const
        {
            Layout::inject(index,my_to_buffer,Layout::project(index,my_fr_buffer));
        }
         
    };
      template
      < typename FrBuffer
      >
        static
      void
    ctor_copy_all(char* to_buffer, FrBuffer* fr_buffer)
    //Call copy construct for all components in to_buffer
    //from corresponding components in fr_buffer.
    {
        ctor_copy_one<FrBuffer> constructor(to_buffer, fr_buffer);
        mpl::for_each<indices>(constructor);
    };
      template
      < typename FrBuffer
      >
      struct
    assign_one
    {

          char*
        my_to_buffer
        ;
          FrBuffer*
        my_fr_buffer
        ;
        assign_one(char* a_to_buffer, FrBuffer* a_fr_buffer)
        : my_to_buffer(a_to_buffer)
        , my_fr_buffer(a_fr_buffer)
        {}
          template
          < class Index
          >
          void
        operator()(Index index)const
        {
            Layout::project(index,my_to_buffer)=Layout::project(index,my_fr_buffer);
        }
         
    };
      template
      < typename FrBuffer
      >
        static
      void
    assign_all(char*to_buffer, FrBuffer*fr_buffer)
    //Call assignment operator for all components in to_buffer
    //from corresponding components in fr_buffer.
    {
        assign_one<FrBuffer> constructor(to_buffer, fr_buffer);
        mpl::for_each<indices>(constructor);
    };
};

}//exit detail_all_of namespace

}//exit detail_composite_tagged//composite_tags::all_of_packed

  template
  < class Index0
  , typename ComponentSeq
  >
  struct
composite_tagged_seq
  < composite_tags::all_of_packed
  , Index0
  , ComponentSeq
  >
: detail_composite_tagged::layout_composite_seq
  < composite_tags::all_of_packed
  , Index0
  , ComponentSeq
  >
{
        typedef
      detail_composite_tagged::layout_composite_seq
      < composite_tags::all_of_packed
      , Index0
      , ComponentSeq
      >
    layout_comp
    ;
        typedef
      typename layout_comp::scanned
    scanned
    ;
        typedef
      typename layout_comp::index_base
    index_base
    ;
        typedef
      typename layout_comp::index_type
    index_type
    ;
        typedef
      detail_composite_tagged::detail_all_of::methods_all<scanned,Index0>
    methods_all
    ;
        static
      std::size_t const
    size
    = scanned::comp_part::size
    ;
 private:
      char
    buffer[size]
    ;
 public:
    composite_tagged_seq(void)
    {
        methods_all::ctor_default_all(buffer);
    }
    composite_tagged_seq(composite_tagged_seq const&from)
    {
        void      *to_buffer=buffer;
        void const*fr_buffer=from.buffer;
        std::memcpy( to_buffer, fr_buffer, size);
    }
 
      template
      < index_type IndexValu
      >
    struct result_type
    {
            typedef
          typename mpl::at_c<ComponentSeq,IndexValu-Index0::value>::type
        type
        ;
    };
      template
      < index_type IndexValu
      >
      void
    inject(typename result_type<IndexValu>::type const& tail_component)
    {
        mpl::integral_c<index_base,IndexValu> index;
        scanned::inject(index,buffer,tail_component);
    }        
      template
      < index_type IndexValu
      >
      void 
    project(typename result_type<IndexValu>::type & tail_component)
    {
        mpl::integral_c<index_base,IndexValu> index;
        scanned::project(index,buffer,tail_component);
    }        
};
#endif //endif#composite_tags::all_of_packed

#if 1 //if#composite_tags::all_of_aligned
namespace detail_composite_tagged//composite_tags::all_of_aligned
{

struct layout_aligned
{
      template
      < std::size_t Size=0
      , std::size_t Align=1
      >
    struct component_layout
    {
            static
          std::size_t const
        size
        =Size
        ;
            static
          std::size_t const
        align
        =Align
        ;
    };
      template
      < typename Component
      >
    struct layout_of
    : component_layout
      < size_of<Component>::value
      , alignment_of<Component>::value
      >
    {
    };
};
  template
  <// class CompositeTag
  >
struct layout_operators< composite_tags::all_of_aligned>
: layout_aligned
{
  
      template
      < typename HeadComposed
      , typename TailLayout
      >
    struct compose_layout
    {
            static
          std::size_t const
        offset
        =aligned_offset
         < HeadComposed::size
         , TailLayout::align
         >::value
        ;
            static
          std::size_t const
        size
        =offset
        +TailLayout::size
        ;
            static
          std::size_t const
        align
        =compatible_alignment
         < HeadComposed::align
         , TailLayout::align
         >::value
        ;
    };
        
      template
      < typename IndexUndefined
      >
    struct layout0
    {
            typedef
          IndexUndefined
        index_part
        ;
            typedef
          component_layout<>
        comp_part
        ;
            static
          void
        inject(void)
        {
        }
            static
          void
        inject_default(void)
        {
        }
            static
          void
        project(void)
        {
        }
            static
          void
        destroy(char*buffer_composite)
        {
        }
    };
    
      template
      < typename HeadLayout
      , typename TailComponent
      >
    struct push_back
    {
          struct
        type
        : private HeadLayout
        {
                typedef
              HeadLayout
            head_layout
            ;
                typedef
              typename mpl::next<typename HeadLayout::index_part>::type
            index_part
            ;
                typedef
              compose_layout
              < typename HeadLayout::comp_part
              , layout_of<TailComponent>
              >
            comp_part
            ;
              using HeadLayout::
            inject
            ;
                static
              void
            inject
              ( index_part index_arg
              , char*buffer_composite
              , TailComponent& tail_component
              )
            {
                void*tail_buffer=buffer_composite+comp_part::offset;
                new(tail_buffer) TailComponent(tail_component);
            }
                static
              void
            inject
              ( index_part index_arg
              , char*buffer_composite
              , TailComponent const& tail_component
              )
            {
                void*tail_buffer=buffer_composite+comp_part::offset;
                new(tail_buffer) TailComponent(tail_component);
            }
              using HeadLayout::
            inject_default
            ;
                static
              void
            inject_default
              ( index_part index_arg
              , char*buffer_composite
              )
            
            {
                TailComponent tail_component;
                inject(index_arg,buffer_composite,tail_component);
            }
              using HeadLayout::
            project
            ;
                static
              TailComponent const&
            project(index_part index_arg, char const*buffer_composite)
            {
                void const*tail_buffer=buffer_composite+comp_part::offset;
                TailComponent const*tail_ptr=static_cast<TailComponent const*>(tail_buffer);
                return *tail_ptr;
            }
                static
              TailComponent&
            project(index_part index_arg, char*buffer_composite)
            {
                void*tail_buffer=buffer_composite+comp_part::offset;
                TailComponent*tail_ptr=static_cast<TailComponent*>(tail_buffer);
                return *tail_ptr;
            }
                static
              void
            destroy( char*buffer_composite)
            {
                TailComponent&tail_ref=project( index_part(), buffer_composite);
                tail_ref.~TailComponent();
                HeadLayout::destroy(buffer_composite);
            }
            
        };//end type struct
    };//end push_back struct
    
      template
      < typename HeadLayout
      >
    struct push_back< HeadLayout, void>
    {
            typedef
          void
        TailComponent
        ;
          struct
        type
        : private HeadLayout
        {
                typedef
              HeadLayout
            head_layout
            ;
                typedef
              typename mpl::next<typename HeadLayout::index_part>::type
            index_part
            ;
              using HeadLayout::
            comp_part
            ;
              using HeadLayout::
            offset
            ;
              using HeadLayout::
            inject
            ;
              using HeadLayout::
            inject_default
            ;
                 static
              void
            inject_default
              ( index_part index_arg
              , char*buffer_composite
              )
            
            {
            }
             using HeadLayout::
            project
            ;
                static
              void
            destroy( char*buffer_composite)
            {
                HeadLayout::destroy(buffer_composite);
            }
            
        };//end type struct
    };//end push_back<.,void> struct
};//end layout_operators struct
  
}//exit detail_composite_tagged namespace//composite_tags::all_of_aligned

  template
  < class Index0
  , typename ComponentSeq
  >
  struct
composite_tagged_seq
  < composite_tags::all_of_aligned
  , Index0
  , ComponentSeq
  >
: detail_composite_tagged::layout_composite_seq
  < composite_tags::all_of_aligned
  , Index0
  , ComponentSeq
  >
{
        typedef
      detail_composite_tagged::layout_composite_seq
      < composite_tags::all_of_aligned
      , Index0
      , ComponentSeq
      >
    layout_comp
    ;
        typedef
      typename layout_comp::scanned
    scanned
    ;
        typedef
      typename layout_comp::index_base
    index_base
    ;
        typedef
      typename layout_comp::index_undefined
    index_undefined
    ;
        typedef
      typename layout_comp::index_type
    index_type
    ;
        typedef
      detail_composite_tagged::detail_all_of::methods_all<scanned,Index0>
    methods_all
    ;
 private:
        typedef
      detail_composite_tagged::aligned_char_storage
      < scanned::comp_part::size
      , scanned::comp_part::align
      >
    buffer_type
    ;
      buffer_type
    buffer
    ;
 public:
    composite_tagged_seq(void)
    {
        char*to_buf=buffer.address();
        methods_all::ctor_default_all(to_buf);
    }
      template
      < typename CompositeConvertible
      >
    composite_tagged_seq( CompositeConvertible& from)
    {
          methods_all::
        ctor_copy_all
        ( buffer.address()
        , from.buffer.address()
        );
    }
      composite_tagged_seq const&
    operator=(composite_tagged_seq const&from)
    {
        char      *to_buf=buffer.address();
        char const*fr_buf=from.buffer.address();
        methods_all::assign_all(to_buf, fr_buf);
        return *this;
    }
    ~composite_tagged_seq(void)
    {
        scanned::destroy( buffer.address());
    }   
 
      template
      < index_type IndexValu
      >
    struct result_type
    {
            typedef
          typename mpl::at_c<ComponentSeq,IndexValu-Index0::value>::type
        type
        ;
    };
      template
      < index_type IndexValu
      >
      typename result_type<IndexValu>::type const&
    project(void)const
    {
        mpl::integral_c<index_base,IndexValu> index;
        return scanned::project(index,buffer.address());
    }        
      template
      < index_type IndexValu
      >
      typename result_type<IndexValu>::type &
    project(void)
    {
        mpl::integral_c<index_base,IndexValu> index;
        return scanned::project(index,buffer.address());
    }        
};
#endif //endif#composite_tags::all_of_aligned

namespace detail_composite_tagged//composite_tags::one_of_maybe
{

  template
  <
  >
  struct 
layout_operators
  < composite_tags::one_of_maybe
  >
: layout_aligned
{
      template
      < typename HeadComposed
      , typename TailLayout
      >
    struct compose_layout
    {
            static
          std::size_t const
        size
        = HeadComposed::size
        > TailLayout::size
        ? HeadComposed::size
        : TailLayout::size
        ;
            static
          std::size_t const
        align
        =compatible_alignment
         < HeadComposed::align
         , TailLayout::align
         >::value
        ;
    };
    
      template
      < typename IndexUndefined
      >
    struct layout0
    {
            typedef
          composite_components::nothing
        tail_type
        ;
            typedef
          IndexUndefined
        index_part
        ;
            typedef
          component_layout<>
        comp_part
        ;
            static
          void
        inject_default( index_part index_arg, char*buffer_composite)
        {
        }
            static
          void
        inject( index_part index_arg, char*buffer_composite, tail_type const&)
        {
        }
            static
          void
        inject_some(void)
        {
        }
            static
          composite_components::nothing const*
        project(index_part index_arg, char const*buffer_composite)
        {
            return composite_components::nothing::_();
        }
            static
          composite_components::nothing*
        project(index_part index_arg, char*buffer_composite)
        {
            return tail_type::_();
        }
            static
          void
        destroyer( index_part index_arg, char*buffer_composite)
        {
        }
    };
    
      template
      < typename HeadLayout
      , typename TailComponent
      >
    struct push_back
    {
        struct type
        : private HeadLayout
        {
                typedef
              HeadLayout
            head_layout
            ;
                typedef
              typename mpl::next<typename HeadLayout::index_part>::type
            index_part
            ;
                typedef
              compose_layout
              < typename HeadLayout::comp_part
              , layout_of<TailComponent>
              >
            comp_part
            ;
              template
              < typename TailConvertible
              , int Dummy=0
              >
              struct
            inject_non_empty
            {
                    static
                  void
                _
                  ( char*buffer_composite
                  )
                {
                    new(buffer_composite) TailComponent;
                }
                    static
                  void
                _
                  ( char*buffer_composite
                  , TailConvertible tail_component
                  )
                {
                    new(buffer_composite) TailComponent(tail_component);
                }
            };

              template
              < int Dummy
              >
              struct
            inject_non_empty
              < composite_components::empty
              , Dummy
              >
            {
                    static
                  void
                _
                  ( char*buffer_composite
                  )
                {
                }
                    static
                  void
                _
                  ( char*buffer_composite
                  , composite_components::empty
                  )
                {
                }
            };
              using HeadLayout::
            inject_default
            ;
                static
              void
            inject_default
              ( index_part index_arg
              , char*buffer_composite
              )
            {
                inject_non_empty<TailComponent>::_(buffer_composite);
            }
            
              using HeadLayout::
            inject
            ;
                static
              void
            inject
              ( index_part index_arg
              , char*buffer_composite
              , TailComponent const& tail_component
              )
            {
                inject_non_empty<TailComponent>::_( buffer_composite, tail_component);
            }
       
              using HeadLayout::
            inject_some
            ;
                static
              void
            inject_some
              ( typename index_part::value_type& index
              , char*buffer_composite
              , TailComponent const& tail_component
              )
            {
                inject( index_part(), buffer_composite, tail_component);
                index=index_part::value;
            }
              using HeadLayout::
            project
            ;
                static
              TailComponent const*
            project(index_part index_arg, char const*buffer_composite)
            {
                void const*tail_buffer=buffer_composite;
                TailComponent const*tail_ptr=static_cast<TailComponent const*>(tail_buffer);
                return tail_ptr;
            }
                static
              TailComponent*
            project(index_part index_arg, char*buffer_composite)
            {
                void*tail_buffer=buffer_composite;
                TailComponent*tail_ptr=static_cast<TailComponent*>(tail_buffer);
                return tail_ptr;
            }
              using HeadLayout::
            destroyer
            ;
              template     
              < typename TailConvertible
              , int Dummy=0
              >
              struct
            destroy_non_empty
            {
                    static
                  void
                _
                  ( void*buffer_composite
                  )
                {
                    TailComponent*tail_ptr=static_cast<TailComponent*>(buffer_composite);
                    tail_ptr->~TailComponent();
                }
            };

              template
              < int Dummy
              >
              struct
            destroy_non_empty
              < composite_components::empty
              , Dummy
              >
            {
                    static
                  void
                _
                  ( void*buffer_composite
                  )
                {
                }
            };
                static
              void
            destroyer( index_part index_arg, char*buffer_composite)
            {
                destroy_non_empty<TailComponent>::_( buffer_composite);
            }
        };
    };
    
};

}//exit detail_composite_tagged//composite_tags::one_of_maybe

//[The following modified from:
//  http://svn.boost.org/svn/boost/sandbox/switch/libs/switch/example/apply_visitor.cpp
//As it was on 2009-12-03.1238 CST
//
// bring switch_ and case_ into scope.
using namespace boost::control;

// One of the cases should always be selected.  If the
// the default is executed it must be an error.
template<class R>
struct never_called 
{
    template<class Int>
    R operator()(Int) 
    {
        BOOST_ASSERT(!"this function should never be called.");
    }
};

namespace visitor_indexed
//  This namespace defines support templates
//  for use of "Index Visitors" taking only index arguments.
//  A "Index Visitor" is a functor with the 
//  "Index Visitor Interface":
//
//    ( mpl::integral_c<IndexType,IndexValu> case_c )
//
//  where:
//    
//    Visitor is an Index Visitor.
//    typedef Visitor::cases::value_type IndexType;
//    IndexType IndexValu;
//
//  the case_c argument above is called 
//    "case argument"
//  below.
//
{

  template
  < class Visitor 
    //functor with signature (case_c,Component) -> Visitor::result_type
    //where:
    //  case_c (see  below).
    //  component is some component of Variant.
    //
  , class Variant
  >
struct visitor_variant
/**@brief
 *  Adapts the Visitor functor to the 
 *  Index Visitor Interface.
 */
{
 public:
        typedef
      typename Visitor::cases
    cases
    ;
        typedef
      typename cases::value_type
    case_type
    ;
        typedef
      typename Visitor::result_type
    result_type
    ;
    visitor_variant( Visitor& visitor, Variant& variant)
        : visitor_(visitor)
        , variant_(variant)
    {}
      template<case_type CaseValu>
      result_type
    operator()
      ( mpl::integral_c<case_type,CaseValu> case_c
      )
    {
            typedef
          typename Variant::index_type
        index_type
        ;
          return
        visitor_
        ( case_c //pass index to visitor
        , *(variant_.template project<index_type(CaseValu)>())//pass component to visitor
        );
    }
 private:
    Visitor& visitor_;
    Variant& variant_;
};

  template
  < class Visitor //an Index Visitor (see above).
  >
  struct
apply_static
{
        typedef
      typename Visitor::result_type
    result_type
    ;
        typedef
      typename Visitor::cases
    cases
    ;
        static
      result_type
    _    
      ( Visitor& visitor
      , typename Visitor::cases::value_type a_case
      )
    {
          never_called<result_type>
        default_
        ;
          return 
        switch_<result_type>(a_case, case_<cases>(visitor), default_);
    }
        static
      result_type
    _    
      ( Visitor const& visitor
      , typename Visitor::cases::value_type a_case
      )
    {
          never_called<result_type>
        default_
        ;
          return 
        switch_<result_type>(a_case, case_<cases>(visitor), default_);
    }
};

  template
  < class Visitor //an Index Visitor (see above).
  >
  typename Visitor::result_type
apply
  ( Visitor& visitor
  , typename Visitor::cases::value_type a_case
  )
{
    return apply_static<Visitor>::_( visitor, a_case);
};

  template
  < class Visitor //an Index Visitor (see above).
  >
  typename Visitor::result_type
apply
  ( Visitor const& visitor
  , typename Visitor::cases::value_type a_case
  )
{
    return apply_static<Visitor>::_( visitor, a_case);
};

}//exit namespace visitor_indexed

//]

namespace detail_composite_tagged
{
namespace detail_one_of_maybe
{

//[apply_visitor_usage

  template
  < typename Layout
  , typename Case0=typename Layout::index_undefined
  >
struct layout_visitor
{
        typedef
      typename Case0::value_type
    case_type
    ;  
        typedef
      mpl::range_c
      < case_type
      , Case0::value
      , Layout::index_end::value
      >
    cases
    ;
};
  template
  < typename Layout
  >
struct assign_copy_visitor
: layout_visitor<Layout>
{
        typedef
      typename layout_visitor<Layout>::case_type
    case_type
    ;
        typedef
      void
    result_type
    ;
      template
      < case_type CaseValu
      >
    result_type operator()( mpl::integral_c<case_type,CaseValu> index) const 
    {
        Layout::scanned::inject( index, my_buffer_0, *Layout::scanned::project(index, my_buffer_1));
    }
    
    assign_copy_visitor
      ( char      * composite_buffer_0
      , char const* composite_buffer_1
      )
    : my_buffer_0(composite_buffer_0)
    , my_buffer_1(composite_buffer_1)
    {}
 private:
      char*
    my_buffer_0
    ;
      char const*
    my_buffer_1
    ;
};

  template
  < typename Layout
  >
struct equal_visitor
: layout_visitor<Layout>
{
        typedef
      typename layout_visitor<Layout>::case_type
    case_type
    ;
        typedef
      bool
    result_type
    ;
      template
      < case_type CaseValu
      >
    result_type operator()( mpl::integral_c<case_type,CaseValu> index) const 
    {
        bool result =
            (*Layout::scanned::project(index, my_buffer_0))
          ==(*Layout::scanned::project(index, my_buffer_1)) ;
        return result ;
    }
    
    equal_visitor
      ( char const* composite_buffer_0
      , char const* composite_buffer_1
      )
    : my_buffer_0( composite_buffer_0)
    , my_buffer_1( composite_buffer_1)
    {}
 private:
      char const*
    my_buffer_0
    ;
      char const*
    my_buffer_1
    ;
};

  template
  < typename Layout
  >
struct destroy_visitor
: layout_visitor<Layout>
{
        typedef
      typename layout_visitor<Layout>::cases
    cases
    ;
        typedef
      typename cases::value_type
    case_type
    ;
        typedef
      void
    result_type
    ;
      template
      < case_type CaseValu
      >
    result_type operator()( mpl::integral_c<case_type,CaseValu> index) const 
    {
        Layout::scanned::destroyer(index,my_buffer);
    }
    
    destroy_visitor
      ( char* composite_buffer
      )
    : my_buffer(composite_buffer)
    {}
 private:
      char*
    my_buffer
    ;
};

//]

}//exit detail_one_of_maybe namespace

}//exit detail_composite_tagged//composite_tags::one_of_maybe


  template
  < class Index0
  , typename ComponentSeq
  >
  struct
composite_tagged_seq
  < composite_tags::one_of_maybe
  , Index0
  , ComponentSeq
  >
: detail_composite_tagged::layout_composite_seq
  < composite_tags::one_of_maybe
  , Index0
  , ComponentSeq
  >
{
        typedef
      detail_composite_tagged::layout_composite_seq
      < composite_tags::one_of_maybe
      , Index0
      , ComponentSeq
      >
    layout_comp
    ;
        typedef
      typename layout_comp::scanned
    scanned
    ;
        typedef
      typename layout_comp::index_base
    index_base
    ;
        typedef
        typename
      detail_composite_tagged::layout_operators
      < composite_tags::all_of_aligned
      >::template push_back
      < scanned
      , index_base
      >::type
    scanned_index
    ;
        typedef
      typename layout_comp::index_undefined
    index_undefined
    ;
        typedef
      typename layout_comp::index_type
    index_type
    ;
 private:
        typedef
      detail_composite_tagged::aligned_char_storage
      < scanned_index::comp_part::size
      , scanned_index::comp_part::align
      >
    buffer_type
    ;
      buffer_type
    buffer
    ;
      void
    destroy(void)
    {
            typedef
          detail_composite_tagged::detail_one_of_maybe::destroy_visitor<layout_comp> 
        visitor_type
        ;
          visitor_type 
        buffer_visitor(buffer.address());
        visitor_indexed::apply(buffer_visitor,which());
    }
      void
    assign_copy( composite_tagged_seq const& from)
    {
            typedef
          detail_composite_tagged::detail_one_of_maybe::assign_copy_visitor<layout_comp> 
        visitor_type
        ;
          visitor_type
        buffer_visitor(buffer.address(), from.buffer.address());
        visitor_indexed::apply(buffer_visitor,from.which());
        which_put(from.which());
    }  
      void
    which_put(index_base new_which)
    {
        typename scanned_index::index_part which_index;
        index_base& result=scanned_index::project(which_index,buffer.address());
        result=new_which;
    }
 public:
      index_base
    which(void)const
    {
        typename scanned_index::index_part which_index;
        index_base const result=scanned_index::project(which_index,buffer.address());
        return result;
    }
      void
    operator=( composite_tagged_seq const& from)
    {
        destroy();
        assign_copy(from);
    }   
    composite_tagged_seq(void)
    {
        which_put(index_undefined::value);
    }
    composite_tagged_seq( composite_tagged_seq const& from)
    {
        assign_copy(from);
    }
      template
      < index_type IndexValu
      , typename Component
      >
    struct index_component
    : fusion::pair
      < mpl::integral_c< index_type, IndexValu>
      , Component
      >
    {
            typedef
          fusion::pair
          < mpl::integral_c< index_type, IndexValu>
          , Component
          >
        super_type
        ;
        index_component(void)
        : super_type(Component())
        {}
        index_component(Component const& a_comp)
        : super_type(a_comp)
        {}
            static
          index_component
        _(void)
        {
            return index_component();
        }
    };
      template
      < index_type IndexValu
      , typename Component
      >
    composite_tagged_seq
      ( index_component<IndexValu,Component> const& index_component
      )
    {
        mpl::integral_c<index_base,IndexValu> index;
        scanned::inject( index, buffer.address(), index_component.second);
        which_put(IndexValu);
    }
      template
      < index_type IndexValu
      , typename Component
      >
      composite_tagged_seq const&
    operator=
      ( index_component<IndexValu,Component> const& index_component
      )
    {
        destroy();
        mpl::integral_c<index_base,IndexValu> index;
        scanned::inject( index, buffer.address(), index_component.second);
        which_put(IndexValu);
        return *this;
    }
    
    ~composite_tagged_seq(void)
    {
        destroy();
    }
      template
      < index_type IndexValu
      >
    struct result_type
    {
            typedef
          typename mpl::at_c<ComponentSeq,IndexValu-Index0::value>::type
        type
        ;
    };
      template
      < index_type IndexValu
      , typename TailConvertible
      >
      void
    inject
      ( TailConvertible tail_component
      )
    {
        destroy();
        mpl::integral_c<index_base,IndexValu> index;
        scanned::inject(index,buffer.address(),tail_component);
        which_put(IndexValu);
    }        
      template
      < index_type IndexValu
      >
      void
    inject
      ( void
      )
    {
        destroy();
        mpl::integral_c<index_base,IndexValu> index;
        scanned::inject_default(index,buffer.address());
        which_put(IndexValu);
    }        
      template
      < index_type IndexValu
      >
      typename result_type<IndexValu>::type const*
    project(void)const
    {
        if(IndexValu == which())
        {
            mpl::integral_c<index_base,IndexValu> index;
            return scanned::project(index,buffer.address());
        }
        else
        {
            return 0;
        }
    }        
      template
      < index_type IndexValu
      >
      typename result_type<IndexValu>::type*
    project(void)
    {
        if(IndexValu == which())
        {
            mpl::integral_c<index_base,IndexValu> index;
            return scanned::project(index,buffer.address());
        }
        else
        {
            return 0;
        }
    }
      bool
    operator==( composite_tagged_seq const& from)const
    {
        if(which() != from.which()) return false;
            typedef
          detail_composite_tagged::detail_one_of_maybe::equal_visitor<layout_comp> 
        visitor_type
        ;
          visitor_type
        buffer_visitor(buffer.address(), from.buffer.address());
        bool is_equal=visitor_indexed::apply(buffer_visitor,which());
        return is_equal;
    }
};

}//exit boost namespace
#endif //endif#BOOST_COMPOSITE_TAGGED_SEQ_INCLUDED
