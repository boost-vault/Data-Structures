#ifndef BOOST_MPL_WHILE_HPP_INCLUDED
#define BOOST_MPL_WHILE_HPP_INCLUDED
// Copyright Larry Evans 2009
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)
//
// See http://www.boost.org/libs/mpl for documentation.

// $Id: while.hpp,v 1.10 2009/02/15 15:33:43 evansl Exp $
// $Date: 2009/02/15 15:33:43 $
// $Revision: 1.10 $

#include <boost/mpl/eval_if.hpp>

namespace boost
{
namespace mpl
{
      template
      < class State //nullary metafunction returning current state.
      , class IfOps //contains nested unary metafunctions, if_, then_.
      >
    struct while_
    : eval_if
      < typename IfOps::template if_<typename State::type>::type
      , while_
        < typename IfOps::template then_<typename State::type>
        , IfOps
        >
      , State
      >
    {
    };
    
}//exit mpl namespace
}//exit boost namespace
#endif
