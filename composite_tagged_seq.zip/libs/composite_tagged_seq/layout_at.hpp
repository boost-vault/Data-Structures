#ifndef BOOST_COMPOSITE_TAGGED_SEQ_LIBS_LAYOUT_AT_INCLUDED
#define BOOST_COMPOSITE_TAGGED_SEQ_LIBS_LAYOUT_AT_INCLUDED
#include <boost/mpl/while.hpp>
#include <boost/mpl/or.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/mpl/integral_c.hpp>
namespace boost
{
namespace detail_composite_tagged
{

   
    template
    < typename IndexUndefined
    , typename IndexType
    >
  struct layout_if
  {
          typedef
        typename IndexUndefined::value_type
      index_base
      ;
          typedef
        mpl::integral_c
        < index_base
        , index_base(IndexType::value)
        >
      index2base
      ;
        template
        < typename Layout
        >
      struct if_
      : mpl::not_
        < mpl::or_
          < is_same<typename Layout::index_part, index2base>
          , is_same<typename Layout::index_part, IndexUndefined>
          >
        >
      {};
      
        template
        < typename Layout
        >
      struct then_
      {
          typedef typename Layout::head_layout type;
      };
  };
  
    template
    < typename Composite
    , typename Index
    >
  struct layout_at
  : mpl::while_
    < typename Composite::scanned
    , layout_if
      < typename Composite::index_undefined
      , Index
      >
    >
  {
  };
  
}}
#endif
