/*=============================================================================
    Copyright (c) 2001-2010 Joel de Guzman

    Distributed under the Boost Software License, Version 1.0. (See accompanying
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
=============================================================================*/
#if !defined(BOOST_SPIRIT_UTREE_DETAIL1)
#define BOOST_SPIRIT_UTREE_DETAIL1

#if defined(BOOST_MSVC)
# pragma warning(push)
# pragma warning(disable: 4804)
# pragma warning(disable: 4805)
# pragma warning(disable: 4244)
#endif

#include <boost/composite_tagged_seq.hpp>

namespace scheme { namespace detail
{
    template <typename UTreeX, typename UTreeY>
    struct visit_impl;
    struct index_impl;

    ///////////////////////////////////////////////////////////////////////////
    // Our utree can store these types. This enum tells us what type
    // of data is stored in utree's discriminated union.
    ///////////////////////////////////////////////////////////////////////////
    struct utree_type
    {
        enum info
        {
            nil_type,
            bool_type,
            int_type,
            double_type,
            list_type,
            reference_type,
            heap_string_type,
            small_string_type
        };
        
        template<info Info>
        struct integral_info
        : boost::mpl::integral_c<info,Info>
        {
        };

    };
}}

namespace boost
{
namespace detail_composite_tagged//general
{

  template
  < scheme::detail::utree_type::info Info
  >
struct enum_base
  < scheme::detail::utree_type::integral_info<Info>
  >
{
    typedef char type;
};

}//exit detail_composite_tagged namespace
}//exit boost namespace
    
namespace scheme { namespace detail
{

    template <typename Iterator>
    void copy_str_iter_size(char* str, Iterator f, std::size_t s);

    template< std::size_t BuffSize>
    struct small_string
    {
    private:
        char buff[BuffSize];
        char& _size()
        {
            return buff[BuffSize-1];
        }
    public:    
        std::size_t size() const
        {
            return buff[BuffSize-1];
        }
        char const* str() const
        {
            return buff;
        }
        
        small_string()
        {
            _size()=0;
        }
        small_string(small_string const& s)
        {
            copy_str_iter_size(buff,s.buff,s.size());
            _size()=s.size();
        }
        void operator=(small_string const& s)
        {
            copy_str_iter_size(buff,s.buff,s.size());
            _size()=s.size();
        }
        
        template <typename Iterator>
        void construct(Iterator f, Iterator l)
        {
            std::size_t s=l-f;
            BOOST_ASSERT(s < BuffSize-1);
            _size()=s;
            copy_str_iter_size(buff,f,s);
        }
        
    };
    
    struct heap_string
    {
    private:
        mutable char* _str;
        mutable std::size_t _size;
    public:    
        std::size_t size() const
        {
            return _size;
        }
        char const* str() const
        {
            return _str;
        }
        heap_string()
        : _str(0)
        , _size(0)
        {}
        
        heap_string(std::size_t a_size)
        : _str(new char[a_size])
        , _size(a_size)
        {}
        
        heap_string(heap_string const& other)
        : _str(other._str)
        , _size(other._size)
        {
            other._str=0;
            other._size=0;
        }
        
        void operator=(heap_string const& other)
        {
            if(this != &other)
            {
                delete[] _str;
                _str=other._str;
                _size=other._size;
                other._str=0;
                other._size=0;
            }
        }
        
        void free()const
        {
            delete [] _str;
            _str=0;
            _size=0;
        }
        
        ~heap_string(void)
        {
            free();
        }
        
        template <typename Iterator>
        void construct(Iterator f, Iterator l)
        {
            std::size_t s=l-f;
            if(s != _size)
            {
                delete [] _str;
                _str=new char[s];
                _size=s;
            }
            copy_str_iter_size(_str,f,s);
        }
        
    };
    
    ///////////////////////////////////////////////////////////////////////////
    // Our POD double linked list. Straightforward implementation.
    // This implementation is very primitive and is not meant to be
    // used stand-alone. This is the internal data representation
    // of lists in our utree.
    ///////////////////////////////////////////////////////////////////////////
    struct list // keep this a POD!
    {
        struct node;

        template <typename Value>
        class node_iterator;

        void free();
        void copy(list const& other);
        void default_construct();
        
        template <typename T>
        void insert_before(T const& val, node* node);

        template <typename T>
        void insert_after(T const& val, node* node);

        template <typename T>
        void push_front(T const& val);

        template <typename T>
        void push_back(T const& val);

        void pop_front();
        void pop_back();
        node* erase(node* pos);

        node* first;
        node* last;
        std::size_t size;
        
        list(void)
        {
            default_construct();
        }
    };
}}

#endif
