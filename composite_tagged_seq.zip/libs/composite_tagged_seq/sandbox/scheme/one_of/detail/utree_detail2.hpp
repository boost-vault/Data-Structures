/*=============================================================================
    Copyright (c) 2001-2010 Joel de Guzman

    Distributed under the Boost Software License, Version 1.0. (See accompanying
    file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
=============================================================================*/
#if !defined(BOOST_SPIRIT_UTREE_DETAIL2)
#define BOOST_SPIRIT_UTREE_DETAIL2

namespace scheme { namespace detail
{

    template<typename Iterator>
    inline void copy_str_iter_size(char* str, Iterator f, std::size_t size)
    {
        for (std::size_t i = 0; i != size; ++i)
        {
            *str++ = *f++;
        }
    }
    
    struct list::node : boost::noncopyable
    {
        template <typename T>
        node(T const& val, node* next, node* prev)
          : val(val), next(next), prev(prev) {}

        void unlink()
        {
            prev->next = next;
            next->prev = prev;
        }

        utree val;
        node* next;
        node* prev;
    };

    template <typename Value>
    class list::node_iterator
      : public boost::iterator_facade<
            node_iterator<Value>
          , Value
          , boost::bidirectional_traversal_tag
        >
    {
    public:

        node_iterator()
          : node(0) {}

        explicit node_iterator(list::node* p)
          : node(p) {}

    private:

        friend class boost::iterator_core_access;
        friend class scheme::utree;

        void increment()
        {
            node = node->next;
        }

        void decrement()
        {
            node = node->prev;
        }

        bool equal(node_iterator const& other) const
        {
            return node == other.node;
        }

        utree& dereference() const
        {
            return node->val;
        }

        list::node* node;
    };

    inline void list::free()
    {
        node* p = first;
        while (p != last)
        {
            node* next = p->next;
            delete p;
            p = next;
        }
        first = last = 0;
        size = 0;
    }

    inline void list::copy(list const& other)
    {
        first = last = 0;
        node* p = other.first;
        while (p != 0)
        {
            push_back(p->val);
            p = p->next;
        }
    }

    inline void list::default_construct()
    {
        first = last = 0;
        size = 0;
    }

    template <typename T>
    inline void list::insert_before(T const& val, node* np)
    {
        BOOST_ASSERT(np != 0);
        node* new_node = new node(val, np, np->prev);
        if (np->prev)
            np->prev->next = new_node;
        else
            first = new_node;
        np->prev = new_node;
        ++size;
    }

    template <typename T>
    inline void list::insert_after(T const& val, node* np)
    {
        BOOST_ASSERT(np != 0);
        node* new_node = new node(val, np->next, np);
        if (np->next)
            np->next->prev = new_node;
        else
            last = new_node;
        np->next = new_node;
        ++size;
    }

    template <typename T>
    inline void list::push_front(T const& val)
    {
        detail::list::node* new_node;
        if (first == 0)
        {
            new_node = new detail::list::node(val, 0, 0);
            first = last = new_node;
            ++size;
        }
        else
        {
             insert_before(val, first);
        }
    }

    template <typename T>
    inline void list::push_back(T const& val)
    {
        if (last == 0)
            push_front(val);
        else
            insert_after(val, last);
    }

    inline void list::pop_front()
    {
        BOOST_ASSERT(size != 0);
        node* np = first;
        first = first->next;
        first->prev = 0;
        delete np;
        --size;
    }

    inline void list::pop_back()
    {
        BOOST_ASSERT(size != 0);
        node* np = last;
        last = last->prev;
        last->next = 0;
        delete np;
        --size;
    }

    inline list::node* list::erase(node* pos)
    {
        BOOST_ASSERT(pos != 0);
        if (pos == first)
        {
            pop_front();
            return first;
        }
        else if (pos == last)
        {
            pop_back();
            return 0;
        }
        else
        {
            node* next(pos->next);
            pos->unlink();
            delete pos;
            --size;
            return next;
        }
    }

    template <typename F, typename X>
    struct bind_impl // simple binder for binary visitation (we don't want to bring in the big guns)
    {
        typedef typename F::result_type result_type;
        X& x; // always by reference
        F f;
        bind_impl(F f, X& x) : x(x), f(f) {}

        template <typename Y>
        typename F::result_type operator()(Y& y) const
        {
            return f(x, y);
        }

        template <typename Y>
        typename F::result_type operator()(Y const& y) const
        {
            return f(x, y);
        }
    };

    template <typename F, typename X>
    bind_impl<F, X const> bind(F f, X const& x)
    {
        return bind_impl<F, X const>(f, x);
    }

    template <typename F, typename X>
    bind_impl<F, X> bind(F f, X& x)
    {
        return bind_impl<F, X>(f, x);
    }

    struct utree_is_equal
    {
        typedef bool result_type;

        template <typename A, typename B>
        bool dispatch(const A&, const B&, boost::mpl::false_) const
        {
            return false; // cannot compare different types by default
        }

        template <typename A, typename B>
        bool dispatch(const A& a, const B& b, boost::mpl::true_) const
        {
            return a == b; // for arithmetic types
        }

        template <typename A, typename B>
        bool operator()(const A& a, const B& b) const
        {
            return dispatch(a, b,
                boost::mpl::and_<
                    boost::is_arithmetic<A>,
                    boost::is_arithmetic<B> >());
        }

        template <typename T>
        bool operator()(const T& a, const T& b) const
        {
            // This code works for lists and strings as well
            return a == b;
        }

        bool operator()(utree::nil, utree::nil) const
        {
            return true;
        }
    };

    struct utree_is_less_than
    {
        typedef bool result_type;

        template <typename A, typename B>
        bool dispatch(const A&, const B&, boost::mpl::false_) const
        {
            return false; // cannot compare different types by default
        }

        template <typename A, typename B>
        bool dispatch(const A& a, const B& b, boost::mpl::true_) const
        {
            return a < b; // for arithmetic types
        }

        template <typename A, typename B>
        bool operator()(const A& a, const B& b) const
        {
            return dispatch(a, b,
                boost::mpl::and_<
                    boost::is_arithmetic<A>,
                    boost::is_arithmetic<B> >());
        }

        template <typename T>
        bool operator()(const T& a, const T& b) const
        {
            // This code works for lists and strings as well
            return a < b;
        }

        bool operator()(utree::nil, utree::nil) const
        {
            BOOST_ASSERT(false);
            return false; // no less than comparison for nil
        }
    };

    template <typename UTreeX, typename UTreeY = UTreeX>
    struct visit_impl
    {
        template <typename F>
        typename F::result_type
        static apply(UTreeX& x, F f) // single dispatch
        {
            typedef typename
                boost::mpl::if_<boost::is_const<UTreeX>, char const*, char*>::type
            string_type;
            typedef typename
                boost::mpl::if_<boost::is_const<UTreeX>, utree::heap_string const, utree::heap_string>::type
            cv_heap_string;
            typedef typename
                boost::mpl::if_<boost::is_const<UTreeX>, utree::small_string const, utree::small_string>::type
            cv_small_string;

            typedef typename
                boost::mpl::if_<boost::is_const<UTreeX>,
                typename UTreeX::const_iterator,
                typename UTreeX::iterator>::type
            iterator;

            typedef boost::iterator_range<iterator> list_range;
            typedef boost::iterator_range<string_type> string_range;
            typedef detail::utree_type type;

            switch (x.get_type())
            {
                default:
                    BOOST_ASSERT(false); // can't happen
                case type::nil_type:
                    typename UTreeX::nil arg;
                    return f(arg);
                case type::bool_type:
                    return f(*x.tagged_union.template project<type::bool_type>());
                case type::int_type:
                    return f(*x.tagged_union.template project<type::int_type>());
                case type::double_type:
                    return f(*x.tagged_union.template project<type::double_type>());
                case type::list_type:
                    return f(list_range(iterator(x.tagged_union.template project<type::list_type>()->first), iterator(0)));
                case type::heap_string_type:
                {
                    cv_heap_string&fs=*x.tagged_union.template project<type::heap_string_type>();
                    return f(string_range(fs.str(), fs.str() + fs.size()));
                }
                case type::small_string_type:
                {
                    cv_small_string&fs=*x.tagged_union.template project<type::small_string_type>();
                    return f(string_range(fs.str(), fs.str() + fs.size()));
                }
                case type::reference_type:
                    return apply(**x.tagged_union.template project<type::reference_type>(), f);
            }
        }

        template <typename F>
        typename F::result_type
        static apply(UTreeX& x, UTreeY& y, F f) // double dispatch
        {
            typedef typename
                boost::mpl::if_<boost::is_const<UTreeX>, char const*, char*>::type
            string_type;
            typedef typename
                boost::mpl::if_<boost::is_const<UTreeX>, utree::heap_string const, utree::heap_string>::type
            cv_heap_string;
            typedef typename
                boost::mpl::if_<boost::is_const<UTreeX>, utree::small_string const, utree::small_string>::type
            cv_small_string;

            typedef typename
                boost::mpl::if_<boost::is_const<UTreeX>,
                typename UTreeX::const_iterator,
                typename UTreeX::iterator>::type
            iterator;

            typedef boost::iterator_range<iterator> list_range;
            typedef boost::iterator_range<string_type> string_range;
            typedef detail::utree_type type;

            switch (x.get_type())
            {
                default:
                    BOOST_ASSERT(false); // can't happen
                case type::nil_type:
                    typename UTreeX::nil x_;
                    return visit_impl::apply(y, detail::bind(f, x_));
                case type::bool_type:
                    return visit_impl::apply(y, detail::bind(f, *x.tagged_union.template project<type::bool_type>()));
                case type::int_type:
                    return visit_impl::apply(y, detail::bind(f, *x.tagged_union.template project<type::int_type>()));
                case type::double_type:
                    return visit_impl::apply(y, detail::bind(f, *x.tagged_union.template project<type::double_type>()));
                case type::list_type:
                    return visit_impl::apply(
                        y, detail::bind<F, list_range>(f,
                        list_range(iterator((*x.tagged_union.template project<type::list_type>()).first), iterator(0))));
                case type::heap_string_type:
                {
                    cv_heap_string&fs=*x.tagged_union.template project<type::heap_string_type>();
                    return visit_impl::apply(y, detail::bind(
                        f, string_range(fs.str(), fs.str() + fs.size())));
                }
                case type::small_string_type:
                {
                    cv_small_string&fs=*x.tagged_union.template project<type::small_string_type>();
                    return visit_impl::apply(y, detail::bind(
                        f, string_range(fs.str(), fs.str() + fs.size())));
                }
                case type::reference_type:
                    return apply(**x.tagged_union.template project<type::reference_type>(), y, f);
            }
        }
    };

    struct index_impl
    {
        static utree& apply(list::node* node, std::size_t i)
        {
            for (; i > 0; --i)
                node = node->next;
            return node->val;
        }

        static utree const& apply(list::node const* node, std::size_t i)
        {
            for (; i > 0; --i)
                node = node->next;
            return node->val;
        }
    };
}}

namespace scheme
{
    inline utree::utree()
    {
        tagged_union.inject<type::nil_type>(nil());
    }

    inline utree::utree(bool b)
    {
        tagged_union.inject<type::bool_type>(b);
    }

    inline utree::utree(unsigned int i)
    {
        tagged_union.inject<type::int_type>(i);
    }

    inline utree::utree(int i)
    {
        tagged_union.inject<type::int_type>(i);
    }

    inline utree::utree(double d)
    {
        tagged_union.inject<type::double_type>(d);
    }

    inline bool utree::small_len_ok(std::size_t len)
    {
      return len<small_string_size;
    }
    inline void utree::inject_string(char const* str)
    {
        std::size_t const len=strlen(str);
        if(!small_len_ok(len))
        {
            utree::heap_string s;
            s.construct(str, str+len);
            tagged_union.inject<type::heap_string_type>(s);
        }
        else
        {
            utree::small_string s;
            s.construct(str, str+len);
            tagged_union.inject<type::small_string_type>(s);
        }
    }

    inline void utree::inject_string(char const* str, std::size_t len)
    {
        if(!small_len_ok(len))
        {
            utree::heap_string s;
            s.construct(str, str+len);
            tagged_union.inject<type::heap_string_type>(s);
        }
        else
        {
            utree::small_string s;
            s.construct(str, str+len);
            tagged_union.inject<type::small_string_type>(s);
        }
    }

    inline void utree::inject_string(std::string const& str)
    {
        std::size_t len=str.size();
        if(!small_len_ok(len))
        {
            utree::heap_string s;
            s.construct(str.begin(), str.end());
            tagged_union.inject<type::heap_string_type>(s);
        }
        else
        {
            utree::small_string s;
            s.construct(str.begin(), str.end());
            tagged_union.inject<type::small_string_type>(s);
        }
    }

    inline utree::utree(char const* str)
    {
        inject_string(str);
    }
    inline utree::utree(char const* str, std::size_t len)
    {
        inject_string(str,len);
    }
    inline utree::utree(std::string const& str)
    {
        inject_string(str);
    }
    
    inline utree::utree(boost::reference_wrapper<utree> ref)
    {
        tagged_union.inject<type::reference_type>(ref.get_pointer());
    }

    inline utree::utree(utree const& other)
    {
        copy(other);
    }

    inline utree& utree::operator=(utree const& other)
    {
        if (this != &other)
        {
            copy(other);
        }
        return *this;
    }

    inline utree& utree::operator=(bool b_)
    {
        tagged_union.inject<type::bool_type>(b_);
        return *this;
    }

    inline utree& utree::operator=(unsigned int i_)
    {
        tagged_union.inject<type::int_type>(i_);
        return *this;
    }

    inline utree& utree::operator=(int i_)
    {
        tagged_union.inject<type::int_type>(i_);
        return *this;
    }

    inline utree& utree::operator=(double d_)
    {
        tagged_union.inject<type::double_type>(d_);
        return *this;
    }

    inline utree& utree::operator=(char const* s_)
    {
        inject_string(s_);
        return *this;
    }

    inline utree& utree::operator=(std::string const& s_)
    {
        inject_string(s_);
        return *this;
    }

    inline utree& utree::operator=(boost::reference_wrapper<utree> ref)
    {
        utree*p = ref.get_pointer();
        tagged_union.inject<type::reference_type>(p);
        return *this;
    }

    template <typename F>
    typename F::result_type
    inline utree::visit(utree const& x, F f)
    {
        return detail::visit_impl<utree const>::apply(x, f);
    }

    template <typename F>
    typename F::result_type
    inline utree::visit(utree& x, F f)
    {
        return detail::visit_impl<utree>::apply(x, f);
    }

    template <typename F>
    typename F::result_type
    inline utree::visit(utree const& x, utree const& y, F f)
    {
        return detail::visit_impl<utree const, utree const>::apply(x, y, f);
    }

    template <typename F>
    typename F::result_type
    inline utree::visit(utree const& x, utree& y, F f)
    {
        return detail::visit_impl<utree const, utree>::apply(x, y, f);
    }

    template <typename F>
    typename F::result_type
    inline utree::visit(utree& x, utree const& y, F f)
    {
        return detail::visit_impl<utree, utree const>::apply(x, y, f);
    }

    template <typename F>
    typename F::result_type
    inline utree::visit(utree& x, utree& y, F f)
    {
        return detail::visit_impl<utree, utree>::apply(x, y, f);
    }

    inline utree& utree::operator[](std::size_t i)
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return (*p)[i];
        }
        BOOST_ASSERT(get_type() == type::list_type && size() > i);
        detail::list&l=*tagged_union.project<type::list_type>();
        return detail::index_impl::apply(l.first, i);
    }

    inline utree const& utree::operator[](std::size_t i) const
    {
        if (get_type() == type::reference_type)
        {
            utree*const p=*tagged_union.project<type::reference_type>();
            return (*p)[i];
        }
        BOOST_ASSERT(get_type() == type::list_type && size() > i);
        detail::list const&l=*tagged_union.project<type::list_type>();
        return detail::index_impl::apply(l.first, i);
    }

    inline bool operator==(utree const& a, utree const& b)
    {
        return utree::visit(a, b, detail::utree_is_equal());
    }

    inline bool operator<(utree const& a, utree const& b)
    {
        return utree::visit(a, b, detail::utree_is_less_than());
    }

    inline bool operator!=(utree const& a, utree const& b)
    {
        return !(a == b);
    }

    inline bool operator>(utree const& a, utree const& b)
    {
        return b < a;
    }

    inline bool operator<=(utree const& a, utree const& b)
    {
        return !(b < a);
    }

    inline bool operator>=(utree const& a, utree const& b)
    {
        return !(a < b);
    }

    template <typename T>
    inline void utree::push_front(T const& val)
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return p->push_front(val);
        }
        ensure_list_type();
        detail::list&l=*tagged_union.project<type::list_type>();
        l.push_front(val);
    }

    template <typename T>
    inline void utree::push_back(T const& val)
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return p->push_back(val);
        }
        ensure_list_type();
        detail::list&l=*tagged_union.project<type::list_type>();
        l.push_back(val);
    }

    template <typename T>
    inline utree::iterator utree::insert(iterator pos, T const& val)
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return p->insert(pos, val);
        }
        ensure_list_type();
        detail::list&l=*tagged_union.project<type::list_type>();
        if (pos.node == l.last)
        {
            push_back(val);
            return begin();
        }
        else
        {
            l.insert_before(val, pos.node);
            return utree::iterator(pos.node->prev);
        }
    }


    template <typename T>
    inline void utree::insert(iterator pos, std::size_t n, T const& val)
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return p->insert(pos, n, val);
        }
        for (std::size_t i = 0; i != n; ++i)
            insert(pos, val);
    }

    template <typename Iter>
    inline void utree::insert(iterator pos, Iter first, Iter last)
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return p->insert(pos, first, last);
        }
        ensure_list_type();
        while (first != last)
            insert(pos, *first++);
    }

    template <typename Iter>
    inline void utree::assign(Iter first, Iter last)
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return p->assign(first, last);
        }
        ensure_list_type();
        clear();
        while (first != last)
            push_back(*first++);
    }

    inline void utree::clear()
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return p->clear();
        }
        // clear will always make this a nil type
        tagged_union.inject<type::nil_type>(nil());
    }

    inline void utree::pop_front()
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return p->pop_front();
        }
        BOOST_ASSERT(get_type() == type::list_type);
        detail::list&l=*tagged_union.project<type::list_type>();
        l.pop_front();
    }

    inline void utree::pop_back()
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return p->pop_back();
        }
        BOOST_ASSERT(get_type() == type::list_type);
        detail::list&l=*tagged_union.project<type::list_type>();
        l.pop_back();
    }

    inline utree::iterator utree::erase(iterator pos)
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return p->erase(pos);
        }
        BOOST_ASSERT(get_type() == type::list_type);
        detail::list&l=*tagged_union.project<type::list_type>();
        return iterator(l.erase(pos.node));
    }

    inline utree::iterator utree::erase(iterator first, iterator last)
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return p->erase(first, last);
        }
        while (first != last)
            erase(first++);
        return last;
    }

    inline utree::iterator utree::begin()
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return p->begin();
        }
        ensure_list_type();
        detail::list&l=*tagged_union.project<type::list_type>();
        return iterator(l.first);
    }

    inline utree::iterator utree::end()
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return p->end();
        }
        ensure_list_type();
        detail::list&l=*tagged_union.project<type::list_type>();
        return iterator(l.last);
    }

    inline utree::const_iterator utree::begin() const
    {
        if (get_type() == type::reference_type)
        {
            utree*const p=*tagged_union.project<type::reference_type>();
            return ((utree const*)p)->begin();
        }
        BOOST_ASSERT(get_type() == type::list_type);
        detail::list const&l=*tagged_union.project<type::list_type>();
        return const_iterator(l.first);
    }

    inline utree::const_iterator utree::end() const
    {
        if (get_type() == type::reference_type)
        {
            utree*const p=*tagged_union.project<type::reference_type>();
            return ((utree const*)p)->end();
        }
        BOOST_ASSERT(get_type() == type::list_type);
        detail::list const&l=*tagged_union.project<type::list_type>();
        return const_iterator(l.last);
    }

    inline bool utree::empty() const
    {
        if (get_type() == type::reference_type)
        {
            utree*const p=*tagged_union.project<type::reference_type>();
            return ((utree const*)p)->empty();
        }
        if (get_type() == type::list_type)
        {
            detail::list const&l=*tagged_union.project<type::list_type>();
            return l.size == 0;
        }
        BOOST_ASSERT(get_type() == type::nil_type);
        return true;
    }

    inline std::size_t utree::size() const
    {
        if (get_type() == type::reference_type)
        {
            utree*const p=*tagged_union.project<type::reference_type>();
            return ((utree const*)p)->size();
        }
        if (get_type() == type::list_type)
        {
            detail::list const&l=*tagged_union.project<type::list_type>();
            return l.size;
        }
        BOOST_ASSERT(get_type() == type::nil_type);
        return 0;
    }

    inline utree& utree::front()
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return p->front();
        }
        BOOST_ASSERT(get_type() == type::list_type);
        detail::list&l=*tagged_union.project<type::list_type>();
        BOOST_ASSERT(l.first != 0);
        return l.first->val;
    }

    inline utree& utree::back()
    {
        if (get_type() == type::reference_type)
        {
            utree*p=*tagged_union.project<type::reference_type>();
            return p->back();
        }
        BOOST_ASSERT(get_type() == type::list_type);
        detail::list &l=*tagged_union.project<type::list_type>();
        BOOST_ASSERT(l.last != 0);
        return l.last->val;
    }

    inline utree const& utree::front() const
    {
        if (get_type() == type::reference_type)
        {
            utree*const p=*tagged_union.project<type::reference_type>();
            return ((utree const*)p)->front();
        }
        BOOST_ASSERT(get_type() == type::list_type);
        detail::list const&l=*tagged_union.project<type::list_type>();
        BOOST_ASSERT(l.first != 0);
        return l.first->val;
    }

    inline utree const& utree::back() const
    {
        if (get_type() == type::reference_type)
        {
            utree*const p=*tagged_union.project<type::reference_type>();
            return ((utree const*)p)->back();
        }
        BOOST_ASSERT(get_type() == type::list_type);
        detail::list const&l=*tagged_union.project<type::list_type>();
        BOOST_ASSERT(l.last != 0);
        return l.last->val;
    }

    inline void utree::swap(utree& other)
    {
        all_composite temp=other.tagged_union;
        other.tagged_union=this->tagged_union;
        this->tagged_union=temp;
    }

    inline utree::type::info utree::get_type() const
    {
        return utree::type::info(tagged_union.which());
    }

    inline void utree::ensure_list_type()
    {
        if (get_type() == type::nil_type)
        {
            detail::list l;
            tagged_union.inject<type::list_type>(l);
        }
        else
        {
            BOOST_ASSERT(get_type() == type::list_type);
        }
    }

    inline void utree::copy(utree const& other)
    {
        this->tagged_union=other.tagged_union;
    }

    inline utree::utree(construct_list)
    {
        detail::list l;
        tagged_union.inject<type::list_type>(l);
    }
}

#endif
