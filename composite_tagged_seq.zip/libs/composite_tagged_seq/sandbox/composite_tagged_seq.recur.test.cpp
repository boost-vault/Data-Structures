//ChangeLog:
//  2009-12-09.0615.CST
//    WHAT:
//      cp'ed from composite_tagged_seq.leaf.test.cpp
//    WHY:
//      provide test driver for recursive composite_tagged_seq.hpp
//
#include <boost/composite_tagged_seq.hpp>
#include <boost/mpl/list.hpp>
#define SMART_PTR_SHARED 1
#define SMART_PTR_UNIQUE (SMART_PTR_SHARED+1)
#define SMART_PTR_WHICH SMART_PTR_UNIQUE
#if SMART_PTR_WHICH == SMART_PTR_SHARED
  #include <boost/shared_ptr.hpp>
  #define SMART_PTR_NAME boost::shared_ptr
#elif SMART_PTR_WHICH == SMART_PTR_UNIQUE
  #include <memory>
  #define SMART_PTR_NAME boost::composite_tagged_recur::unique_ptr
#endif  
#include <iostream>
#include <iomanip>

namespace boost
{
namespace composite_tagged_recur
{
#if SMART_PTR_WHICH == SMART_PTR_UNIQUE
  template
  < typename Pointee
  >
struct unique_ptr
: public std::unique_ptr<Pointee>
{
        typedef
      std::unique_ptr<Pointee>
    super_type
    ;
        typedef
      unique_ptr<Pointee>
    self_type
    ;
      void
    reset_release(self_type& self_other)
    {
        this->reset(self_other.release());
    }
      void
    reset_release(self_type const& self_cons)
    {
        self_type&self_mut=const_cast<self_type&>(self_cons);
        reset_release(self_mut);
    }
      self_type const&
    operator=(self_type& self_other)
    {
        reset_release(self_other);
        return *this;
    }
      self_type& 
    operator=(const self_type& self_cons) 
    {
        reset_release(self_cons);
        return *this;
    }
    unique_ptr(void)
    {}
    unique_ptr(self_type const& self_other)
    {
        reset_release(self_other);
    }
    unique_ptr(self_type& self_other)
    {
        reset_release(self_other);
    }
    unique_ptr(Pointee* pointee)
    : super_type(pointee)
    {
    }
    ~unique_ptr(void)
    {
        Pointee*pointee=this->get();
        if(pointee)
        {
            std::cout<<"~unique_ptr:deleting "<<pointee->my_id<<"\n";
        }
    }
};
  
#endif
    static
  unsigned
object_id
=0
;
    static
  int
object_number
=0
;
//#define TRACE_OBJ_TORS
struct obj
{
      unsigned const
    my_id
    ;
    obj(void)
    : my_id(++object_id)
    {
        ++object_number;
      #ifdef TRACE_OBJ_TORS
        std::cout<<"obj(void):my_id="<<my_id<<":object_number="<<object_number<<":this="<<this<<"\n";
      #endif
    }
    obj(obj const&you)
    : my_id(++object_id)
    {
        ++object_number;
      #ifdef TRACE_OBJ_TORS
        std::cout<<"obj(obj cont&):my_id="<<my_id<<":object_number="<<object_number<<":this="<<this<<"\n";
        std::cout<<"you.my_id="<<you.my_id<<"\n";
      #endif
    }
    ~obj(void)
    {
        --object_number;
      #ifdef TRACE_OBJ_TORS
        std::cout<<"~obj(void):my_id="<<my_id<<":object_number="<<object_number<<":this="<<this<<"\n";
      #endif
    }
      void
    operator=(obj const&)
    {}
};
  template
  < unsigned I
  >
  struct
charvec_u
: obj
{
    char v[2*(I+1)];
    unsigned tag(void)const
    {
        return I;
    }
    charvec_u(void)
    {
        v[0]='a';
        v[1]='\0';
    }
};

enum list_numerals
{ tag_nil
, tag_cons
};
struct list_nil
{};
enum cons_numerals
{ tag_head
, tag_tail
};

  template
  < typename Element
  >
struct list_recur
;
  template
  < typename Element
  >
struct super_cons
{
        typedef
      composite_tagged_seq
      < composite_tags::all_of_aligned
      , mpl::integral_c<cons_numerals,tag_head>
      , mpl::list
        < Element
        , SMART_PTR_NAME<list_recur<Element> >
        >
      >
    type
    ;
};
  template
  < typename Element
  >
struct list_cons
: obj
, super_cons<Element>::type
{
        typedef
      typename super_cons<Element>::type
    super_type
    ;
    list_cons(void)
    {
        list_recur<Element>*val_tail=super_type::template project<tag_tail>().get();
        std::cout
          <<"list_cons(void):\n"
          <<": val_tail="<<val_tail<<"\n"
          <<": this->my_id="<<this->my_id<<"\n"
          ;
    }
    list_cons
      ( Element const& val_head
      ,   SMART_PTR_NAME<list_recur<Element> >
        #if SMART_PTR_WHICH == SMART_PTR_UNIQUE
        #else
          const
        #endif
        & val_tail
      )
    {
        super_type::template project<tag_head>()=val_head;
        super_type::template project<tag_tail>()=val_tail;
        list_recur<Element>*my_tail=super_type::template project<tag_tail>().get();
        std::cout
          <<"list_cons(val_head,val_tail):\n"
          <<": val_tail="<<val_tail<<"\n"
          <<": my_tail="<<my_tail<<"\n"
          <<": this->my_id="<<this->my_id<<"\n"
          <<": tail->my_id="<<my_tail->my_id<<"\n"
          ;
    }
      list_cons const&
    operator=(list_cons const& val_cons)
    {
        super_type::operator=(val_cons);
        list_recur<Element>*my_tail=super_type::template project<tag_tail>().get();
        std::cout
          <<"list_cons::operator=(list_cons const&):\n"
          <<": my_tail="<<my_tail<<"\n"
          <<": this->my_id="<<this->my_id<<"\n"
          <<": tail->my_id="<<my_tail->my_id<<"\n"
          ;
        return *this;
    }
    list_cons(list_cons const& val_cons)
    {
        this->operator=(val_cons);
    }
    ~list_cons(void)
    {
        list_recur<Element>*val_tail=super_type::template project<tag_tail>().get();
      #if 1
        if(val_tail)
        {
            std::cout
              <<"~list_cons:\n"
              <<": val_tail="<<val_tail<<"\n"
              <<": this->my_id="<<this->my_id<<"\n"
              <<": tail->my_id="<<val_tail->my_id<<"\n"
              ;
        }
        else
            std::cout<<"~list_cons with null tail\n";
      #endif
    }
};  
  template
  < typename Element
  >
struct list_recur
: obj
, composite_tagged_seq
  < composite_tags::one_of_maybe
  , mpl::integral_c<list_numerals,tag_nil>
  , mpl::list
    < list_nil
    , list_cons<Element>
    >
  >
{
};

  template
  < typename Element
  >
struct list_recur_print
{
        static
      unsigned const
    inc=2
    ;
        typedef
      list_recur<Element>
    list_type
    ;
    list_recur_print
      ( list_type const*a_list
      , std::ostream&a_out=std::cout
      )
    : indent_(0)
    , list_(a_list)
    , out_(a_out)
    {}
    
      void
    print(void)
    {
        out_<<std::setw(indent_)<<"";
        if(!list_)
        {
            out_<<"(list_recur*)0\n";
        }
        else
        {
            out_<<"list_recur:my_id="<<list_->my_id<<"\n";
            int tag=list_->which();
            switch(tag)
            {
              case tag_nil:
                out_<<"list_nil\n";
                break;
              case tag_cons:
                { 
                    list_cons<Element>const*cons=list_->template project<tag_cons>();
                    out_<<"list_cons:my_id="<<cons->my_id<<"\n";
                    out_<<std::setw(inc)<<"";
                    out_<<cons->template project<tag_head>()<<"\n";
                    indent_+=inc;
                    SMART_PTR_NAME<list_type>const&sp=cons->template project<tag_tail>();
                    list_=sp.get();
                    print();
                }
                break;
              default:
                out_<<"***list_recur has bad tag!\n";
                break;
            }
        }
    }
    
      int
    indent_
    ;
      list_type const*
    list_
    ;
      std::ostream&
    out_
    ;
        static
      void
    _
      ( SMART_PTR_NAME<list_type> const&a_list_ptr
      , std::ostream&a_out=std::cout
      )
    {
        list_recur_print lp(a_list_ptr.get(),a_out);
        lp.print();
    }
};
  
  template
  < typename Element
  >
  std::ostream&
operator<<
  ( std::ostream& sout
  , SMART_PTR_NAME<list_recur<Element> >const& x
  )
{
    list_recur_print<Element>::_(x,sout);
    return sout;
}
  template
  < unsigned I 
  >
  std::ostream&
operator<<
  ( std::ostream& sout
  , charvec_u<I>const& x
  )
{
    sout<<"charvec_u<"<<I<<">";
    sout<<": my_id="<<x.my_id;
    return std::cout;
}

void test(void)
{
#if 1
    std::cout<<"object_number="<<object_number<<"\n";
    {
            typedef
          charvec_u<2>
        element_type
        ;
            typedef
          list_recur<element_type>
        list_2_type
        ;
            typedef
          SMART_PTR_NAME<list_2_type>
        list_2_ptype
        ;
          list_2_ptype
        list_2_ptr(new list_2_type)
        ;
        std::cout<<"begin:list2_ptr="<<list_2_ptr<<"\n";
        std::cout<<"no_inject:list_2_ptr->which="<<list_2_ptr->which()<<"\n";
        list_2_ptr->inject<tag_nil>(list_nil());
        std::cout<<"inject<tag_nil>:list_2_ptr.which="<<list_2_ptr->which()<<"\n";
        list_cons<element_type> list_cons_1(element_type(),list_2_ptr);
        list_2_ptr.reset(new list_2_type);
        list_2_ptr->inject<tag_cons>(list_cons_1);
        std::cout<<"inject<tag_cons>:list_2_ptr.which="<<list_2_ptr->which()<<"\n";
        std::cout<<"end:list2_ptr=\n"<<list_2_ptr<<"\n";
    }
#endif    
    std::cout<<"final:object_number="<<object_number<<"\n";
}

}//exit composite_tagged_recur namespace
}//exit boost namespace

int main(void)
{
    boost::composite_tagged_recur::test();
    return 0;
}    
