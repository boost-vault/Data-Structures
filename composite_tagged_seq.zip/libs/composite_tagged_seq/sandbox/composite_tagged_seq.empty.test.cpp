//ChangeLog:
//  2009-12-25
//    WHAT:
//      cp'ed from composite_tagged_seq.leaf.test.cpp
//    WHY:
//      provide test driver for composites with composite_components::empty
//      components.
//
#include <boost/composite_tagged_seq.hpp>
#include <boost/mpl/list.hpp>
#include <boost/mpl/for_each.hpp>

#include <boost/iostreams/utility/indent_scoped_ostreambuf.hpp>
#include <iostream>
#include <sstream>

struct trace_scope
{
    trace_scope(std::string const& a_where)
    : my_where(a_where)
    {
        std::cout<<"[[[ENTERING:"<<my_where<<"\n";
        std::cout<<indent_buf_in;
    }
    ~trace_scope(void)
    {
        std::cout<<indent_buf_out;
        std::cout<<"]]]EXITING:"<<my_where<<"\n";
    }
 private:
      std::string
    my_where
    ;    
};
  
namespace boost
{
namespace composite_tagged_empty
{
    static
  unsigned
object_id
=0
;
    static
  int
object_number
=0
;
struct obj
{
      unsigned const
    my_id
    ;
    obj(void)
    : my_id(++object_id)
    {
        ++object_number;
    }
    obj(obj const&)
    : my_id(++object_id)
    {
        ++object_number;
    }
    ~obj(void)
    {
        --object_number;
    }
      void
    operator=(obj const&)
    {}
};
  template
  < unsigned I
  >
  struct
charvec_u
: obj
{
    char v[9*(I+1)];
    unsigned tag(void)const
    {
        return I;
    }
    charvec_u(void)
    {
        v[0]='a'+I;
        v[1]='\0';
    }
        friend
      std::ostream&
    operator<<
      ( std::ostream& sout
      , charvec_u<I> const& self
      )
    {
        sout<<"chavec_u<"<<I<<">:="<<self.v;
        return sout;
    }
};

  std::ostream&
operator<<
  ( std::ostream& sout
  , composite_components::empty const& x
  )
{
    sout<<"&composite_components::empty="<<&x;
    return sout;
}
    
  template
  < typename Val
  >
struct wrap_ptr
;  
  template
  < typename Val
  >
struct wrap_ptr
  < Val*
  >
{
    wrap_ptr(Val*a_ptr):my_ptr(a_ptr){}
    Val*my_ptr;
    
        friend
      std::ostream&
    operator<<
      ( std::ostream& sout
      , wrap_ptr<Val*>const a_wrap
      )
    {
        if(a_wrap.my_ptr)
        {
            sout<<*a_wrap.my_ptr;
        }
        else
        {
            sout<<"(null)";
        }
        return sout;
    }
          
};
  template
  < typename Val
  >
  wrap_ptr<Val*>
mk_wrap 
  ( Val*ptr
  )
{
    return wrap_ptr<Val*>(ptr);
}
      
  enum
index_numerals
{ index_0
, index_1
, index_2
, index_3
, index_4
};

  template<typename T>
struct type_name_
;  
  template<>
struct type_name_<composite_components::empty>
{
        static
      char const*
    _(void)
    { 
        return "composite_components::empty";
    }
};  
  template<>
struct type_name_<composite_components::empty&>
{
        static
      char const*
    _(void)
    { 
        return "composite_components::empty&";
    }
};
  std::string
uns2str(unsigned I)
{
    std::ostringstream stream;
    stream<<I;
    return stream.str();
}
  template<unsigned I>
struct type_name_<charvec_u<I> >
{
        static
      std::string
    _(void)
    { 
        return "charvec_u<"+uns2str(I)+">";
    }
};
  template<unsigned I>
struct type_name_<charvec_u<I>&>
{
        static
      std::string
    _(void)
    { 
        return "charvec_u<"+uns2str(I)+">&";
    }
};
  template<typename T>
  std::string
type_name(void)
{
    return type_name_<T>::_();
}

struct print_scan_size
{
      template<typename T>
      void
    operator()(T&)
    {
        std::size_t sizeof_v=sizeof(T);
        std::size_t size_of=detail_composite_tagged::size_alignment_of<T>::size;
        std::cout
          <<type_name<T>()
          <<":sizeof="<<sizeof_v
          <<":size_of="<<size_of
          <<":sum_size="<<(sum_sizes+=size_of)
          <<"\n";
    }
    print_scan_size(void)
    : sum_sizes(0)
    {}
      unsigned
    sum_sizes
    ;
};

void test(void)
{
#if 1
    std::cout<<"object_number="<<object_number<<"\n";
    {  
        trace_scope ts("one_of_maybe empty TESTS");
            typedef  
          mpl::list
          < charvec_u<0>
          , charvec_u<1>
          , composite_components::empty
          >
        components
        ;
        print_scan_size printer;
        mpl::for_each<components>(printer);
            typedef
          composite_tagged_seq
          < composite_tags::one_of_maybe
          , mpl::integral_c<index_numerals,index_0>
          , components
          >
        tagged_type
        ;
            typedef
          tagged_type::layout_comp::scanned
        layout_scanned
        ;
        std::cout
          <<"***composite_tagged<one_of_maybe>:\n"
          <<":size="<<layout_scanned::size_part<<"\n"
          <<":alignment="<<layout_scanned::align_part<<"\n"
        ;
          tagged_type 
        tagged_values
        ;
          charvec_u<0>*
        t0
        ;
          charvec_u<1>*
        t1
        ;
          composite_components::empty*
        t2
        ;
        std::cout
          <<"which="<<tagged_values.which()<<"\n";
        t0=tagged_values.project<index_0>();
        std::cout
          <<"t0="<<mk_wrap(t0)<<"\n";
        t1=tagged_values.project<index_1>();
        std::cout
          <<"t1="<<mk_wrap(t1)<<"\n";
        t2=tagged_values.project<index_2>();
        std::cout
          <<"t2="<<mk_wrap(t2)<<"\n";
          
        tagged_values.inject<index_0>(charvec_u<0>());
        std::cout
          <<"which="<<tagged_values.which()<<"\n";
        t0=tagged_values.project<index_0>();
        std::cout
          <<"t0="<<mk_wrap(t0)<<"\n";
        t1=tagged_values.project<index_1>();
        std::cout
          <<"t1="<<mk_wrap(t1)<<"\n";
          
        tagged_values.inject<index_2>();
        std::cout
          <<"which="<<tagged_values.which()<<"\n";
        t0=tagged_values.project<index_0>();
        std::cout
          <<"t0="<<mk_wrap(t0)<<"\n";
        t1=tagged_values.project<index_1>();
        std::cout
          <<"t1="<<mk_wrap(t1)<<"\n";
        t2=tagged_values.project<index_2>();
        std::cout
          <<"t2="<<mk_wrap(t2)<<"\n";
        std::cout
          <<"assign_test:\n";
          tagged_type
        tagged_from
        ;
        tagged_values=tagged_from;
                std::cout
          <<"which="<<tagged_values.which()<<"\n";
        t0=tagged_values.project<index_0>();
        std::cout
          <<"t0="<<mk_wrap(t0)<<"\n";
        t1=tagged_values.project<index_1>();
        std::cout
          <<"t1="<<mk_wrap(t1)<<"\n";

    }
#endif    
#if 1
    std::cout<<"object_number="<<object_number<<"\n";
    {  
        trace_scope ts("all_of_aligned empty TESTS");
            typedef  
          mpl::list
          < charvec_u<0>
          , charvec_u<1>
          , composite_components::empty
          >
        components
        ;
        print_scan_size printer;
        mpl::for_each<components>(printer);
            typedef
          composite_tagged_seq
          < composite_tags::all_of_aligned
          , mpl::integral_c<index_numerals,index_0>
          , components
          >
        tagged_type
        ;
            typedef
          tagged_type::layout_comp::scanned
        layout_scanned
        ;
        std::cout
          <<"***composite_tagged<all_of_aligned>:\n"
          <<":size="<<layout_scanned::size_part<<"\n"
          <<":alignment="<<layout_scanned::align_part<<"\n"
        ;
          tagged_type 
        tagged_values
        ;
          charvec_u<0>
        t0
        ;
          charvec_u<1>
        t1
        ;
          composite_components::empty
        t2
        ;
        t0=tagged_values.project<index_0>();
        std::cout
          <<"t0="<<t0<<"\n";
        t1=tagged_values.project<index_1>();
        std::cout
          <<"t1="<<t1<<"\n";
        t2=tagged_values.project<index_2>();
        std::cout
          <<"t2="<<t2<<"\n";
    }
#endif    
#if 1
    std::cout<<"object_number="<<object_number<<"\n";
    {  
        trace_scope ts("all_of_aligned void TESTS");
            typedef  
          mpl::list
          < charvec_u<0>
          , void
          , charvec_u<2>
          >
        components
        ;
            typedef
          composite_tagged_seq
          < composite_tags::all_of_aligned
          , mpl::integral_c<index_numerals,index_0>
          , components
          >
        tagged_type
        ;
            typedef
          tagged_type::layout_comp::scanned
        layout_scanned
        ;
        std::cout
          <<"***composite_tagged<all_of_aligned>:\n"
          <<":size="<<layout_scanned::size_part<<"\n"
          <<":alignment="<<layout_scanned::align_part<<"\n"
        ;
          tagged_type 
        tagged_values
        ;
          charvec_u<0>
        t0
        ;
          charvec_u<2>
        t2
        ;
        t0=tagged_values.project<index_0>();
        std::cout
          <<"t0="<<t0<<"\n";
      #if 0
        tagged_values.project<index_1>(); //should fail to compile
      #endif
        t2=tagged_values.project<index_2>();
        std::cout
          <<"t2="<<t2<<"\n";
    }
#endif    
    std::cout<<"final:object_number="<<object_number<<"\n";
}

}//exit composite_tagged_empty namespace
}//exit boost namespace

int main(void)
{
    boost::iostreams::indent_scoped_ostreambuf<> ind_out(std::cout);
    boost::composite_tagged_empty::test();
    return 0;
}    
