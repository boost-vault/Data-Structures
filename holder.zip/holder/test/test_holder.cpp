
#define BOOST_TEST_NO_LIB
#define BOOST_TEST_NO_MAIN
#include <boost/test/unit_test.hpp>

#include <string>
#include <boost/holder/holder.hpp>
#include <boost/holder/method.hpp>

#include <boost/tuple/tuple.hpp>
#include <boost/utility.hpp>

using namespace std;
using namespace boost;
using namespace unit_test;
using namespace unit_test_framework;
using namespace boost::holders;



namespace TestHolder {

   BOOST_AUTO_TEST_CASE(test_member)
   {
      holder h00;
      BOOST_CHECK_EQUAL(h00.empty(), true);
      BOOST_CHECK(!((h00.type().before(holders::holder::type<void>())))||(holders::holder::type<void>().before(h00.type())));
      BOOST_CHECK_EQUAL(h00.number(), holders::number<void>());
   }
}

namespace TestValueHolder {

   BOOST_AUTO_TEST_CASE(test_create)
   {
      holder h00;
      int i(100);
      h00.reset<int>(i);
      BOOST_CHECK_EQUAL((*h00.cast<int>()), 100);

      double j(1000.0);
      h00.reset<double>(j);
      BOOST_CHECK_EQUAL((*h00.cast<double>()), 1000.0);

      h00.reset<tuple<int, double> >(i, j);
      BOOST_CHECK_EQUAL((h00.cast<tuple<int, double> >()->get<0>()), 100);
      BOOST_CHECK_EQUAL((h00.cast<tuple<int, double> >()->get<1>()), 1000.0);

      char k('a');
      h00.reset<tuple<int, double, char> >(i, j, k);
      BOOST_CHECK_EQUAL((h00.cast<tuple<int, double, char> >()->get<0>()), 100);
      BOOST_CHECK_EQUAL((h00.cast<tuple<int, double, char> >()->get<1>()), 1000.0);
      BOOST_CHECK_EQUAL((h00.cast<tuple<int, double, char> >()->get<2>()), 'a');

      h00.reset<tuple<int, double, char, int, double, char, char> >(i, j, k, i, j, k, k);
      BOOST_CHECK_EQUAL((h00.cast<tuple<int, double, char, int, double, char, char> >()->get<0>()), 100);
      BOOST_CHECK_EQUAL((h00.cast<tuple<int, double, char, int, double, char, char> >()->get<1>()), 1000.0);
      BOOST_CHECK_EQUAL((h00.cast<tuple<int, double, char, int, double, char, char> >()->get<2>()), 'a');
      BOOST_CHECK_EQUAL((h00.cast<tuple<int, double, char, int, double, char, char> >()->get<3>()), 100);
      BOOST_CHECK_EQUAL((h00.cast<tuple<int, double, char, int, double, char, char> >()->get<4>()), 1000.0);
      BOOST_CHECK_EQUAL((h00.cast<tuple<int, double, char, int, double, char, char> >()->get<5>()), 'a');
      BOOST_CHECK_EQUAL((h00.cast<tuple<int, double, char, int, double, char, char> >()->get<6>()), 'a');

      holder h01(h00);
      h00.reset<char>('b');
      BOOST_CHECK_EQUAL((*h00.cast<char>()), 'b');

   }
}


namespace TestSharedHolder {

   BOOST_AUTO_TEST_CASE(test_create)
   {
      holder h00;
      int i(100);
      h00.reset<int, boost::holders::shared_container>(i);
      BOOST_CHECK_EQUAL((*h00.cast<int>()), 100);

      holder h01(h00);
      BOOST_CHECK_EQUAL((*h01.cast<int>()), 100);

      (*h00.cast<int>()) = 200;
      BOOST_CHECK_EQUAL((*h01.cast<int>()), 200);

      h00.reset<int>(300);
      BOOST_CHECK_EQUAL((*h01.cast<int>()), 200);

   }
}


namespace TestNoncopyableHolder {

   class A : boost::noncopyable {};

   BOOST_AUTO_TEST_CASE(test_create)
   {
      holder h00, h01;
      h00.reset<A, noncopyable_container>();
      BOOST_CHECK_THROW(h01 = h00, bad_clone);
      BOOST_CHECK_THROW(holder h03(h00), bad_clone);
   }

}


namespace TestReference {

   BOOST_AUTO_TEST_CASE(test_create)
   {
      int i(100);
      holder h00;
      h00.reset<int&>(i);
      BOOST_CHECK_EQUAL((*h00.cast<int>()), 100);

      i = 200;
      BOOST_CHECK_EQUAL((*h00.cast<int>()), 200);

      i = 300;
      BOOST_CHECK_EQUAL((*h00.cast<int>()), 300);
   }

}