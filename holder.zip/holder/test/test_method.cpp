
#define BOOST_TEST_NO_LIB
#define BOOST_TEST_NO_MAIN
#include <boost/test/unit_test.hpp>

#include <string>
#include <boost/holder/holder.hpp>
#include <boost/holder/method.hpp>

using namespace std;
using namespace boost;
using namespace unit_test;
using namespace unit_test_framework;

#include <iostream>
#include <conio.h>
#include <boost/tuple/tuple.hpp>
#include <boost/format.hpp>
#include <boost/timer.hpp>
#include <boost/function.hpp>

namespace TestMethod {
   struct A {
      string operator()() { return "A()"; };
      string operator()(int a0) { return str(format("A(int:%d)") % a0); };
      string operator()(double& a0) { return str(format("A(double&:%d)") % a0); };
      string operator()(const double& a0) { return str(format("A(const double&:%d)") % a0); };
      string operator()(int a0, double a1) { return str(format("A(int:%d, double:%d)") % a0 % a1); };
   };

namespace TestMethod00 {
   
   struct methods : public boost::holders::methods_base<methods> {};
   bool A001(methods::caller<string(A)>::entry<A>());
   bool A002(methods::caller<string(A, int)>::entry<A, int>());
   bool A003(methods::caller<string(A, const int&)>::entry<A, const int&>());
   bool A004(methods::caller<string(A, double)>::entry<A, double>());
   bool A005(methods::caller<string(A, const double&)>::entry<A, const double&>());
   bool A006(methods::caller<string(A, int, double)>::entry<A, int, double>());
   bool A007(methods::caller<string(A, const int&, const double&)>::entry<A, int, double>());

   BOOST_AUTO_TEST_CASE(test00)
   {
      A a;
      BOOST_CHECK_EQUAL(methods::apply<string>(a), "A()");
      int i(100);
      BOOST_CHECK_EQUAL(methods::apply<string>(a, i), "A(int:100)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, 100), "A(int:100)");
      double d(100);
      BOOST_CHECK_EQUAL(methods::apply<string>(a, d), "A(double&:100)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, 100.0), "A(const double&:100)");

      BOOST_CHECK_EQUAL(methods::apply<string>(a, i, d), "A(int:100, double:100)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, 100, 100.0), "A(int:100, double:100)");
   }
}

   struct methods : public boost::holders::methods_base<methods> {};

   BOOST_AUTO_TEST_CASE(test)
   {
      A a;
      BOOST_CHECK_THROW(methods::apply<string>(a), boost::holders::bad_method);
  }
}


namespace TestReference {
   struct A {
      string operator()() { return "A()"; };
      string operator()(int& a0) { return str(format("A(int:%d)") % (++a0)); };
      string operator()(double& a0) { return str(format("A(double:%d)") % (++a0)); };
      string operator()(int a0, double a1) { return str(format("A(int:%d, double:%d)") % (++a0) % (++a1)); };
   };

   struct methods : public boost::holders::methods_base<methods> {};
   bool A001(methods::caller<string(A)>::entry<A>());
   bool A002(methods::caller<string(A, int)>::entry<A, int>());
   bool A004(methods::caller<string(A, double)>::entry<A, double>());
   bool A006(methods::caller<string(A, int, double)>::entry<A, int, double>());

   BOOST_AUTO_TEST_CASE(test00)
   {
      A a;
      int i(100);
      double d(100);
      BOOST_CHECK_EQUAL(methods::apply<string>(a), "A()");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, i), "A(int:101)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, i), "A(int:102)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, i), "A(int:103)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, d), "A(double:101)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, d), "A(double:102)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, d), "A(double:103)");

      BOOST_CHECK_EQUAL(methods::apply<string>(a, i, d), "A(int:104, double:104)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, i, d), "A(int:104, double:104)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, i, d), "A(int:104, double:104)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, i, d), "A(int:104, double:104)");
   }
}


namespace TestHolder {
   struct A {
      string operator()() { return "A()"; };
      string operator()(int& a0) { return str(format("A(int:%d)") % (++a0)); };
      string operator()(double& a0) { return str(format("A(double:%d)") % (++a0)); };
      string operator()(int a0, double a1) { return str(format("A(int:%d, double:%d)") % (++a0) % (++a1)); };
   };

   struct methods : public boost::holders::methods_base<methods> {};
   bool A003(methods::caller<string(A, holders::holder)>::entry<A, int>());
   bool A004(methods::caller<string(A, holders::holder)>::entry<A, double>());
   bool A006(methods::caller<string(A, holders::holder, holders::holder)>::entry<A, int, double>());

   BOOST_AUTO_TEST_CASE(test00)
   {
      A a;
      holders::holder h00;
      h00.reset<int>(100);
      holders::holder h01;
      h01.reset<double>(100.0);
      BOOST_CHECK_EQUAL(methods::apply<string>(a, h00), "A(int:101)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, h00), "A(int:102)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, h00), "A(int:103)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, h01), "A(double:101)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, h01), "A(double:102)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, h01), "A(double:103)");

      BOOST_CHECK_EQUAL(methods::apply<string>(a, h00, h01), "A(int:104, double:104)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, h00, h01), "A(int:104, double:104)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, h00, h01), "A(int:104, double:104)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a, h00, h01), "A(int:104, double:104)");
   }
}



namespace TestSetHolder {

   template<typename T>
   class arg {
   public:
      typedef T type;
      arg(T& t) : t_(t), h_() {};
      arg(holders::holder& h, T& t) : t_(t), h_(h) {};
      holders::holder holder() { return h_; };
      T& value() { return t_; };
   private:
      type& t_;
      holders::holder h_;
   };

   struct processor {
      template<typename R>
      struct main {
#        define BOOST_HOLDER_RULE_TUPLE_PROCESSOR(z, n, tag)                              \
            template<BOOST_PP_ENUM_PARAMS(BOOST_PP_INC(n), typename A)>                   \
            R operator () (BOOST_PP_ENUM_BINARY_PARAMS(BOOST_PP_INC(n), A, & a)) {        \
               return a0.value()(BOOST_PP_ENUM_PARAMS(BOOST_PP_INC(n), a));               \
            };
         BOOST_PP_REPEAT(BOOST_HOLDER_METHOD_MAX_ARGS, BOOST_HOLDER_RULE_TUPLE_PROCESSOR, nil)
      };
   };

   struct caster {
      template<typename R>
      struct traits {
         static R& cast(R& target) {
            return target;
         };
         static R cast(holders::holder& target) {
            return R(target, holders::holder_cast<R::type&>(target));
         };
         static unsigned int type() {
            return holders::holder::number<typename R::type>();
         };
      };
      template<typename R>
      struct traits<arg<R> > {
         typedef typename arg<R> arg_type;
         static arg_type& cast(arg_type& target) {
            return target;
         };
         static arg_type cast(holders::holder& target) {
            return arg_type(target, holders::holder_cast<R&>(target));
         };
         static unsigned int type() {
            return holders::holder::number<R>();
         };
      };
      template<typename M, typename T>
      static typename M& find(M& method, T& target) { return method; };
      template<typename M>
      static typename M& find(M& method, boost::holders::holder& target) {
         return method.methods_[target.number()];
      };
      template<typename T, typename M>
      static typename M& find(M& method) {
         return method.methods_[traits<T>::type()];
      };
   };

   struct methods : public boost::holders::methods_base<methods, processor, caster> {};

   struct A {
      string operator()() { return "A()"; };
      string operator()(arg<A> a0, arg<int> a1) {
         return str(format("A(int:%d)") % (++(a1.value())));
      };
      string operator()(arg<A> a0, arg<double> a1) {
         return str(format("A(double:%d)") % (++(a1.value())));
      };
      string operator()(arg<A> a0, arg<int> a1, arg<double> a2) {
         return str(format("A(int:%d, double:%d)") % (++(a1.value())) % (++(a2.value())));
      };
   };

   bool A003(methods::caller<string(holders::holder, holders::holder)>::entry<arg<A>, arg<int> >());
   bool A004(methods::caller<string(holders::holder, holders::holder)>::entry<arg<A>, arg<double> >());
   bool A006(methods::caller<string(holders::holder, holders::holder, holders::holder)>::entry<arg<A>, arg<int>, arg<double> >());

   BOOST_AUTO_TEST_CASE(test00)
   {
      holders::holder a00;
      a00.reset<A>();
      holders::holder h00;
      h00.reset<int>(100);
      holders::holder h01;
      h01.reset<double>(100.0);
      BOOST_CHECK_EQUAL(methods::apply<string>(a00, h00), "A(int:101)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a00, h00), "A(int:102)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a00, h00), "A(int:103)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a00, h01), "A(double:101)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a00, h01), "A(double:102)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a00, h01), "A(double:103)");

      BOOST_CHECK_EQUAL(methods::apply<string>(a00, h00, h01), "A(int:104, double:104)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a00, h00, h01), "A(int:105, double:105)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a00, h00, h01), "A(int:106, double:106)");
      BOOST_CHECK_EQUAL(methods::apply<string>(a00, h00, h01), "A(int:107, double:107)");
   }
}



namespace TestTime {
   
   static const int count = 1000000000;

   struct Timer {
      Timer(string s) : s_(s) {};
      ~Timer() {
         std::cout << s_ << ": " << timer_.elapsed() << " sec." << std::endl;
      };
      string s_;
      boost::timer timer_;
   };
   struct A {
      unsigned int operator()(unsigned int a0) { return a0; };
      unsigned int operator()(unsigned int a0, unsigned int a1) { return a0+a1; };
      unsigned int operator()(unsigned int a0, unsigned int a1, unsigned int a2) { return a0+a1+a2; };
   };

   struct methods : public boost::holders::methods_base<methods> {};
   bool A000(methods::caller<unsigned int (A, unsigned int)>::entry<A, unsigned int>());
   bool A001(methods::caller<unsigned int (holders::holder, unsigned int)>::entry<A, unsigned int>());
   bool A002(methods::caller<unsigned int (holders::holder, holders::holder)>::entry<A, unsigned int>());
   bool A003(methods::caller<const unsigned int (holders::holder, const unsigned int&)>::entry<A, const unsigned int&>());

   bool A005(methods::caller<unsigned int (A, unsigned int, unsigned int, unsigned int)>::entry<A, unsigned int, unsigned int, unsigned int>());

   bool A007(methods::caller<unsigned int (holders::holder, holders::holder, holders::holder, holders::holder)>::entry<A, unsigned int, unsigned int, unsigned int>());


   BOOST_AUTO_TEST_CASE(test00)
   {
      {
         Timer t("function object");
         A a;
         for (unsigned int i = 0; i < count; ++i) {
            a(100);
         }
      }
      {
         Timer t("boost::function");
         A a;
         boost::function<unsigned int(unsigned int)> f01(a);
         for (unsigned int i = 0; i < count; ++i) {
            f01(100u);
         }
      }
      {
         Timer t("rare method");
         A a;
         unsigned int j(100);
         for (unsigned int i = 0; i < count; ++i) {
            methods::apply<unsigned int>(a, j);
         }
      }
      {
         Timer t("holder method");
         holders::holder h;
         h.reset<A>();
         holders::holder hh;
         hh.reset<unsigned int>(100);
         for (unsigned int i = 0; i < count; ++i) {
            methods::apply<unsigned int>(h, hh);
         }
      }
   }
   BOOST_AUTO_TEST_CASE(test01)
   {
      {
         Timer t("function object");
         A a;
         for (unsigned int i = 0; i < count; ++i) {
            a(100, 100, 100);
         }
      }
      {
         Timer t("boost::function");
         A a;
         boost::function<unsigned int(unsigned int, unsigned int, unsigned int)> f01(a);
         for (unsigned int i = 0; i < count; ++i) {
            f01(100u, 100u, 100u);
         }
      }
      {
         Timer t("rare method");
         A a;
         unsigned int j(100);
         for (unsigned int i = 0; i < count; ++i) {
            methods::apply<unsigned int>(a, j, j, j);
         }
      }
      {
         Timer t("holder method");
         holders::holder h;
         h.reset<A>();
         holders::holder hh;
         hh.reset<unsigned int>(100);
         for (unsigned int i = 0; i < count; ++i) {
            methods::apply<unsigned int>(h, hh, hh, hh);
         }
      }
   }
}


