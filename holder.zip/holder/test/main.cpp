#include <iostream>
#include <conio.h>
#include <string>
#include <boost/timer.hpp>


struct Timer {
   ~Timer() {
      std::cout << "Test time: " << timer_.elapsed() << " sec." << std::endl;
      std::cout << "Press any key" << std::endl;
      getchar();
   };
   boost::timer timer_;
} timer;

#define BOOST_TEST_MODULE Test
#define BOOST_TEST_MAIN
#include <boost/test/included/unit_test.hpp>

