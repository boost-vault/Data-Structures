#ifndef BOOST_HOLDER_HPP
#define BOOST_HOLDER_HPP
/*---------------------------------------------------------------------------
   holder.hpp

   ---------------------------------------------------------------------------
   Copyright (C) 2009/3 - 2009 Nowake fiercewinds.net
----------------------------------------------------------------------------*/

#include <typeinfo>

#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/type_traits/add_reference.hpp>
#include <boost/type_traits/remove_reference.hpp>

#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>
#include <boost/preprocessor/seq/elem.hpp>


#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/repetition/enum.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>
#include <boost/preprocessor/repetition/repeat_from_to.hpp>

#include <boost/preprocessor/seq/for_each_product.hpp>
#include <boost/preprocessor/seq/elem.hpp>

#include <boost/preprocessor/control/expr_if.hpp>


namespace boost {
namespace holders {

// -special function to uniformize type_info ---------------------------------
// To get unique instance of type_info, multimethod's function use this function.
// Now we can use type_info's pointer to compare each type.
// ---------------------------------------------------------------------------
template<typename T>
struct type {
   static const std::type_info& typeinfo() {
      static const std::type_info& r(typeid(T));
      return r;
   }
};
template<typename T>
struct type<const T> {
   struct id {};
   static const std::type_info& typeinfo() {
      return type<T>::typeinfo();
   }
};
inline unsigned int count() { static unsigned int r(0); return r++; };
template<typename T>
unsigned int number() { static unsigned int r(count()); return r; };

// -container class-----------------------------------------------------------
// ---------------------------------------------------------------------------

#ifndef BOOST_HOLDER_MAX_ARITY
#  define BOOST_HOLDER_MAX_ARITY 9
#endif


class container {
public:
   virtual const std::type_info& type() const = 0;
   virtual unsigned int number() const = 0;
   virtual boost::shared_ptr<container> clone() = 0;
   virtual boost::shared_ptr<container> fission() = 0;
};

template<typename T>
class container_data {
public:
   typedef typename boost::add_reference<T>::type content_ref;
   typedef typename boost::remove_reference<T>::type content_type;
   virtual const std::type_info& type() const { return boost::holders::type<content_type>::typeinfo(); };
   virtual unsigned int number() const { return boost::holders::number<content_type>(); };
   content_ref content() { return content_; };
#  define BOOST_HOLDER_container_data_CONSTRACTOR(z, n, tags)                                      \
      BOOST_PP_EXPR_IF(n,                                                                          \
         template<BOOST_PP_ENUM_PARAMS(n, typename BOOST_PP_SEQ_ELEM(2, tags))>                    \
      )                                                                                            \
      BOOST_PP_SEQ_ELEM(0, tags)(                                                                  \
         BOOST_PP_ENUM_BINARY_PARAMS(n, BOOST_PP_SEQ_ELEM(2, tags), & BOOST_PP_SEQ_ELEM(3, tags))  \
      ) : BOOST_PP_SEQ_ELEM(1, tags)(                                                              \
         BOOST_PP_ENUM_PARAMS(n, BOOST_PP_SEQ_ELEM(3, tags))                                       \
      ) {};
   BOOST_PP_REPEAT(BOOST_HOLDER_MAX_ARITY, BOOST_HOLDER_container_data_CONSTRACTOR, (container_data)(content_)(A)(a))
   ~container_data() {};
private:
   content_type content_;
};


template<typename T>
class container_base : public container {
public:
   typedef T content_type;
   typedef typename boost::add_reference<T>::type content_ref;
   virtual const std::type_info& type() const { return boost::holders::type<content_type>::typeinfo(); };
   virtual unsigned int number() const { return boost::holders::number<content_type>(); };
   content_ref content() { return content_ref_; };
protected:
   container_base(boost::shared_ptr<container_data<T> > data) : data_(data), content_ref_(data_->content()) {};
   container_base(content_ref data) : data_(), content_ref_(data) {};
   ~container_base() {};
   boost::shared_ptr<container_data<T> > data_;
   content_ref content_ref_;
};



#define BOOST_HOLDER_CREATOR(z, n, tags)                                                        \
   BOOST_PP_EXPR_IF(n,                                                                          \
      template<BOOST_PP_ENUM_PARAMS(n, typename BOOST_PP_SEQ_ELEM(2, tags))>                    \
   )                                                                                            \
   static boost::shared_ptr<BOOST_PP_SEQ_ELEM(0, tags)> create(                                 \
      BOOST_PP_ENUM_BINARY_PARAMS(n, BOOST_PP_SEQ_ELEM(2, tags), & BOOST_PP_SEQ_ELEM(3, tags))  \
   ) {                                                                                          \
      return boost::shared_ptr<BOOST_PP_SEQ_ELEM(0, tags)>(                                     \
         new BOOST_PP_SEQ_ELEM(1, tags)                                                         \
            BOOST_PP_EXPR_IF(n,(BOOST_PP_ENUM_PARAMS(n, BOOST_PP_SEQ_ELEM(3, tags))))           \
         , deleter());                                                                          \
   };

#define BOOST_HOLDER_DATA_CONSTRACTOR(z, n, tags)                                               \
   BOOST_PP_EXPR_IF(n,                                                                          \
      template<BOOST_PP_ENUM_PARAMS(n, typename BOOST_PP_SEQ_ELEM(2, tags))>                    \
   )                                                                                            \
   BOOST_PP_SEQ_ELEM(0, tags)(                                                                  \
      BOOST_PP_ENUM_BINARY_PARAMS(n, BOOST_PP_SEQ_ELEM(2, tags), & BOOST_PP_SEQ_ELEM(3, tags))  \
   ) : BOOST_PP_SEQ_ELEM(1, tags)(                                                              \
      boost::shared_ptr<container_data<T> >(new container_data<T>(                              \
      BOOST_PP_ENUM_PARAMS(n, BOOST_PP_SEQ_ELEM(3, tags))                                       \
   ))) {};


template<typename T>
class shared_container : public container_base<T>, public boost::enable_shared_from_this<shared_container<T> > {
public:
   virtual boost::shared_ptr<container> clone() { return shared_from_this(); };
   virtual boost::shared_ptr<container> fission() { return shared_from_this(); };
public:
   BOOST_PP_REPEAT(BOOST_HOLDER_MAX_ARITY, BOOST_HOLDER_CREATOR, (shared_container)(shared_container)(A)(a))
protected:
   BOOST_PP_REPEAT(BOOST_HOLDER_MAX_ARITY, BOOST_HOLDER_DATA_CONSTRACTOR, (shared_container)(container_base<T>)(A)(a))
   ~shared_container() {};
   struct deleter { void operator()(shared_container* value) { delete value; }; };
   friend deleter;
};

template<typename T>
class shared_container<T&> : public container_base<T>, public boost::enable_shared_from_this<shared_container<T&> > {
public:
   virtual boost::shared_ptr<container> clone() { return shared_from_this(); };
   virtual boost::shared_ptr<container> fission() { return shared_from_this(); };
public:
   static boost::shared_ptr<shared_container> create(T& target) {
      return boost::shared_ptr<shared_container>(new shared_container(target), deleter());
   };
protected:
   shared_container(T& target) : container_base<T>(target) {};
   ~shared_container() {};
   struct deleter { void operator()(shared_container* value) { delete value; }; };
   friend deleter;
};


template<typename T>
class value_container : public container_base<T> {
public:
   virtual boost::shared_ptr<container> clone() {
      return boost::shared_ptr<value_container>(new value_container(content_ref_), deleter());
   };
   virtual boost::shared_ptr<container> fission() { return clone(); };
public:
   BOOST_PP_REPEAT(BOOST_HOLDER_MAX_ARITY, BOOST_HOLDER_CREATOR, (value_container)(value_container)(A)(a))
protected:
   BOOST_PP_REPEAT(BOOST_HOLDER_MAX_ARITY, BOOST_HOLDER_DATA_CONSTRACTOR, (value_container)(container_base<T>)(A)(a))
   ~value_container() {};
   struct deleter { void operator()(value_container* value) { delete value; }; };
   friend deleter;
};
template<typename T> class value_container<T&>;


class bad_clone : public std::exception {
public:
   virtual const char * what() const throw() {
      return "Bad holder clone: this is noncopyable container.";
   };
};

template<typename T>
class noncopyable_container : public container_base<T> {
public:
   virtual boost::shared_ptr<container> clone() { throw bad_clone(); };
   virtual boost::shared_ptr<container> fission() { throw bad_clone(); };
public:
   BOOST_PP_REPEAT(BOOST_HOLDER_MAX_ARITY, BOOST_HOLDER_CREATOR, (noncopyable_container)(noncopyable_container)(A)(a))
protected:
   BOOST_PP_REPEAT(BOOST_HOLDER_MAX_ARITY, BOOST_HOLDER_DATA_CONSTRACTOR, (noncopyable_container)(container_base<T>)(A)(a))
   ~noncopyable_container() {};
   struct deleter { void operator()(noncopyable_container* value) { delete value; }; };
   friend deleter;
};

template<typename T>
class noncopyable_container<T&> : public container_base<T> {
public:
   virtual boost::shared_ptr<container> clone() { throw bad_clone(); };
   virtual boost::shared_ptr<container> fission() { throw bad_clone(); };
public:
   static boost::shared_ptr<noncopyable_container> create(T& target) {
      return boost::shared_ptr<noncopyable_container>(new noncopyable_container(target), deleter());
   };
protected:
   noncopyable_container(T& target) : container_base<T>(target) {};
   ~noncopyable_container() {};
   struct deleter { void operator()(noncopyable_container* value) { delete value; }; };
   friend deleter;
};


// -holder--------------------------------------------------------------------
// ---------------------------------------------------------------------------
class holder {
public:
   holder() : container_() {};

   template<typename content_type>
   holder(const content_type& content) : container_(shared_container<content_type>::create(content)) {};

   holder(boost::shared_ptr<container> container) : container_(container) {};

   holder(const holder& other) : container_() {
      if (other.empty()) return;
      container_ = other.container_->fission();
   };

   template<typename T>
   holder& operator=(const T& other) {
      holder(other).swap(*this);
      return *this;
   }

   ~holder() {};

 public:
   holder& swap(holder& other) {
      container_.swap(other.container_);
      return *this;
   }

   holder& operator=(const holder& other) {
      holder(other).swap(*this);
      return *this;
   }

   holder reference() {
      holder r;
      r.container_ = container_;
      return r;
   };

   void reset() {
      container_.reset();
   };

   void reset(boost::shared_ptr<container> container) {
      container_.swap(container);
   };

   template<typename content_type>
   void reset(typename boost::add_reference<content_type>::type value) {
      container_ = shared_container<content_type>::create(value);
   };

   template<typename content_type, template<typename> class container_type>
   void reset(typename boost::add_reference<content_type>::type value) {
      container_ = container_type<content_type>::create(value);
   };


#  define BOOST_HOLDER_DEFAULT_RESET(z, n, tags)                                                                        \
      template<typename content_type BOOST_PP_COMMA_IF(n) BOOST_PP_ENUM_PARAMS(n, typename BOOST_PP_SEQ_ELEM(0, tags))> \
      void reset (BOOST_PP_ENUM_BINARY_PARAMS(n, BOOST_PP_SEQ_ELEM(0, tags), const & BOOST_PP_SEQ_ELEM(1, tags))) {     \
         container_ = shared_container<content_type>::create(BOOST_PP_ENUM_PARAMS(n, BOOST_PP_SEQ_ELEM(1, tags)));      \
      };

   BOOST_PP_REPEAT(BOOST_HOLDER_MAX_ARITY, BOOST_HOLDER_DEFAULT_RESET, (A)(a))

#  define BOOST_HOLDER_RESET(z, n, tags)                                                                             \
      template<typename content_type, template<typename> class container_type                                        \
         BOOST_PP_COMMA_IF(n) BOOST_PP_ENUM_PARAMS(n, typename BOOST_PP_SEQ_ELEM(0, tags))>                          \
      void reset (BOOST_PP_ENUM_BINARY_PARAMS(n, BOOST_PP_SEQ_ELEM(0, tags), const & BOOST_PP_SEQ_ELEM(1, tags))) {  \
         container_ = container_type<content_type>::create(BOOST_PP_ENUM_PARAMS(n, BOOST_PP_SEQ_ELEM(1, tags)));     \
      };

   BOOST_PP_REPEAT(BOOST_HOLDER_MAX_ARITY, BOOST_HOLDER_RESET, (A)(a))


 public:
   template<typename T>
   static const std::type_info& type() { return boost::holders::type<T>::typeinfo(); };

   template<typename T>
   static unsigned int number() { return boost::holders::number<T>(); };

   const std::type_info& type() const {
      return container_ ? container_->type() : boost::holders::type<void>::typeinfo();
   }

   const unsigned int number() const {
      return container_ ? container_->number() : boost::holders::number<void>();
   }

   bool empty() const {
      return !(container_.get());
   }

   template<typename T>
   typename boost::remove_reference<T>::type* cast() {
      typedef typename boost::remove_reference<T>::type type;
      return container_.get() && container_->number() == boost::holders::number<type>() ? unsafe<type>() : 0;
   }

   template<typename T>
   typename boost::remove_reference<T>::type* unsafe() {
      typedef typename boost::remove_reference<T>::type type;
      return &(static_cast<container_base<type>*>(container_.get())->content());
   }

private:
   boost::shared_ptr<container> container_;

};


class bad_holder_cast : public std::bad_cast {
public:
   virtual const char * what() const throw() {
      return "bad_holder_cast: "
             "failed conversion using holder_cast";
   }
};


template<typename T>
inline T* holder_cast(holder* target) {
   return target ? target->cast<T>() : 0;
}

template<typename T>
inline const T* holder_cast(const holder* target) {
   return holder_cast<T>(const_cast<holder*>(target));
}

template<typename T>
inline typename add_reference<T>::type holder_cast(holder& target) {
   typedef BOOST_DEDUCED_TYPENAME remove_reference<T>::type nonref;
   nonref* result = holder_cast<nonref>(&target);
   if(result) return *result;
   throw bad_holder_cast();
}

template<typename T>
inline typename add_reference<T>::type holder_cast(const holder& target) {
   typedef BOOST_DEDUCED_TYPENAME remove_reference<T>::type nonref;
   return holder_cast<const nonref&>(const_cast<holder&>(target));
}

};
};

#endif
