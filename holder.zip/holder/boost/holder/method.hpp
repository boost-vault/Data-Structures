#ifndef BOOST_HOLDER_METHOD_HPP
#define BOOST_HOLDER_METHOD_HPP
/*---------------------------------------------------------------------------
   method.hpp

   ---------------------------------------------------------------------------
   Copyright (C) 2009/3 - 2009 Nowake fiercewinds.net
----------------------------------------------------------------------------*/

#include <typeinfo>
#include <map>
#include <vector>

#include <boost/unordered_map.hpp>

#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/type_traits/add_reference.hpp>
#include <boost/type_traits/remove_reference.hpp>
#include <boost/type_traits/add_const.hpp>

#include <boost/preprocessor/control/if.hpp>

#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>
#include <boost/preprocessor/repetition/enum_shifted_params.hpp> 
#include <boost/preprocessor/repetition/repeat_from_to.hpp>

#include <boost/preprocessor/arithmetic/inc.hpp>

#include <boost/preprocessor/facilities/identity.hpp>

#include <boost/preprocessor/seq/for_each_product.hpp>
#include <boost/preprocessor/seq/for_each.hpp>
#include <boost/preprocessor/seq/enum.hpp>
#include <boost/preprocessor/seq/cat.hpp>
#include <boost/preprocessor/seq/elem.hpp>

#include <boost/preprocessor/control/expr_if.hpp>

#include <boost/holder/holder.hpp>


namespace boost {
namespace holders {

#ifndef BOOST_HOLDER_METHOD_MAX_ARGS
#  define BOOST_HOLDER_METHOD_MAX_ARGS 7
#endif

//*

// -holder methods (visitor) -------------------------------------------------
// ---------------------------------------------------------------------------

   class bad_method : public std::exception {
   public:
      virtual const char * what() const throw() {
         return "Bad method: this is no trampoline.";
      };
   };


   namespace detail {
      struct rule {
         struct processor {
            template<typename R>
            struct main {
#              define BOOST_HOLDER_RULE_PROCESSOR(z, n, tag)                                    \
                  template<BOOST_PP_ENUM_PARAMS(BOOST_PP_INC(n), typename A)>                   \
                  R operator () (BOOST_PP_ENUM_BINARY_PARAMS(BOOST_PP_INC(n), A, & a)) {        \
                     return a0 (BOOST_PP_ENUM_SHIFTED_PARAMS(BOOST_PP_INC(n), a));              \
                  };
               BOOST_PP_REPEAT(BOOST_HOLDER_METHOD_MAX_ARGS, BOOST_HOLDER_RULE_PROCESSOR, nil)
            };

            template<>
            struct main<void> {
#              define BOOST_HOLDER_RULE_VOID_PROCESSOR(z, n, tag)                                  \
                  template<BOOST_PP_ENUM_PARAMS(BOOST_PP_INC(n), typename A)>                      \
                  void operator () (BOOST_PP_ENUM_BINARY_PARAMS(BOOST_PP_INC(n), A, & a)) {        \
                     a0 (BOOST_PP_ENUM_SHIFTED_PARAMS(BOOST_PP_INC(n), a));                        \
                  };
               BOOST_PP_REPEAT(BOOST_HOLDER_METHOD_MAX_ARGS, BOOST_HOLDER_RULE_VOID_PROCESSOR, nil)
            };
         };

         struct caster {
            template<typename R>
            struct traits {
               static R& cast(R& target) { return target; };
               static const R& cast(const R& target) { return target; };
               static R& cast(holder& target) {
                  //return holder_cast<R&>(target);
                  return *(target.unsafe<R>());
               };
               static unsigned int type() { return holders::holder::number<R>(); };
            };
            template<typename R>
            struct traits<const R&> {
               static const R& cast(const R& target) { return target; };
               static const R& cast(const holder& target) {
                  //return holder_cast<const R&>(target);
                  return *(target.unsafe<const R&>());
               };
               static unsigned int type() { return holders::holder::number<const R&>(); };
            };
            template<typename R>
            struct traits<R&> {
               static R& cast(R& target) { return target; };
               static R& cast(holder& target) {
                  //return holder_cast<R&>(target);
                  return *(target.unsafe<R&>());
               };
               static unsigned int type() { return holders::holder::number<R&>(); };
            };
            template<typename M, typename T>
            static typename M& find(M& method, T& target) { return method; };
            template<typename M>
            static typename M& find(M& method, holder& target) {
               return method.methods_[target.number()];
            };
            template<typename T, typename M>
            static typename M& find(M& method) {
               return method.methods_[traits<T>::type()];
            };
         };
         struct missing {
            template<typename R>
            struct main {
               R operator()(...) { throw bad_method(); };
            };
         };
      };
   };


// ---------------------------------------------------------------------------

#define BOOST_HOLDER_METHOD_REF_ARG(z, n, text)    typedef typename boost::add_reference<text ## n>::type R ## text ## n;
#define BOOST_HOLDER_METHOD_CASTED_ARGS(z, n, value) \
   caster_type::traits<BOOST_PP_SEQ_CAT((BOOST_PP_SEQ_ELEM(0, value))(n))>::cast(BOOST_PP_SEQ_CAT((BOOST_PP_SEQ_ELEM(1, value))(n)))

#define BOOST_HOLDER_METHOD_TRAMPOLINE_VALUE_FINDER(z, n, text) .find(text##n)

#define BOOST_HOLDER_METHOD_TRAMPOLINE_SETUP(z, n, text) .setup<text##n>(t)
#define BOOST_HOLDER_METHOD_TRAMPOLINE(z, n, value)                                                         \
   method() BOOST_PP_REPEAT_FROM_TO(n, BOOST_PP_SEQ_ELEM(0, value), BOOST_HOLDER_METHOD_TRAMPOLINE_SETUP, BOOST_PP_SEQ_ELEM(1, value));

#define BOOST_HOLDER_METHOD_ENTRY(n)                                                            \
   BOOST_PP_EXPR_IF(n,                                                                          \
   template<BOOST_PP_ENUM_PARAMS(n, typename A)> static bool entry() {                          \
      return entry<BOOST_PP_ENUM_PARAMS(n, typename A) BOOST_PP_COMMA_IF(n) processor_type>();  \
   };)

#define BOOST_HOLDER_METHOD_ENTRY_PROCESSOR(n)                                               \
   template<BOOST_PP_ENUM_PARAMS(n, typename A) BOOST_PP_COMMA_IF(n) typename processor_t>   \
   static bool entry(processor_t processor) {                                                \
      entry<BOOST_PP_ENUM_PARAMS(n, A), processor_t BOOST_PP_COMMA_IF(n) caster_type>();     \
      trampoline<BOOST_PP_ENUM_PARAMS(n, typename A) BOOST_PP_COMMA_IF(n) processor_t        \
         >::processor() = processor;                                                         \
      return true;                                                                           \
   };


// Apply Function Maker
#define BOOST_HOLDER_METHOD_APPLY_FUNCTION_ARG_SET(z, n, tag)        \
   (((BOOST_PP_SEQ_CAT((BOOST_PP_SEQ_ELEM(0, tag))(n))&)             \
     (BOOST_PP_SEQ_CAT((BOOST_PP_SEQ_ELEM(0, tag))(n)))              \
     (BOOST_PP_SEQ_CAT((BOOST_PP_SEQ_ELEM(1, tag))(n))))             \
    (( const BOOST_PP_SEQ_CAT((BOOST_PP_SEQ_ELEM(0, tag))(n))&)      \
     ( const BOOST_PP_SEQ_CAT((BOOST_PP_SEQ_ELEM(0, tag))(n))&)      \
     (BOOST_PP_SEQ_CAT((BOOST_PP_SEQ_ELEM(1, tag))(n))))             \
    )


#define BOOST_HOLDER_METHOD_APPLY_FUNCTION_ARGS_SETS(n, tag)            \
   BOOST_PP_IF(n,                                                       \
   BOOST_PP_REPEAT(n, BOOST_HOLDER_METHOD_APPLY_FUNCTION_ARG_SET, tag), \
   (((void)(void))))

#define BOOST_HOLDER_METHOD_APPLY_FUNCTION_PARAM0(r, data, seq)   \
   (BOOST_PP_SEQ_ELEM(0, seq) BOOST_PP_SEQ_ELEM(2, seq))

#define BOOST_HOLDER_METHOD_APPLY_FUNCTION_PARAM1(r, data, seq)   \
   (BOOST_PP_SEQ_ELEM(1, seq))

#define BOOST_HOLDER_METHOD_APPLY_FUNCTION_PARAMS_JOINT(r, product)                   \
   ((BOOST_PP_SEQ_FOR_EACH(BOOST_HOLDER_METHOD_APPLY_FUNCTION_PARAM0, r, product))    \
    (BOOST_PP_SEQ_FOR_EACH(BOOST_HOLDER_METHOD_APPLY_FUNCTION_PARAM1, r, product)))


#define BOOST_HOLDER_METHOD_APPLY_FUNCTION_PARAMS(n, tag)                                                                                    \
   BOOST_PP_IF(n,                                                                                                                            \
      BOOST_PP_SEQ_FOR_EACH_PRODUCT(BOOST_HOLDER_METHOD_APPLY_FUNCTION_PARAMS_JOINT, BOOST_HOLDER_METHOD_APPLY_FUNCTION_ARGS_SETS(n, tag)),  \
      (((void))((void))))


#define BOOST_HOLDER_METHOD_APPLY_FUNCTION_PARAM_JOINT(r, data, elem)                                                \
template<typename R                                                                                                  \
      BOOST_PP_EXPR_IF(BOOST_PP_SEQ_ELEM(0, data), BOOST_PP_COMMA()                                                  \
      BOOST_PP_ENUM_PARAMS(BOOST_PP_SEQ_ELEM(0, data), typename BOOST_PP_SEQ_ELEM(0, BOOST_PP_SEQ_ELEM(1, data))))   \
   > static R apply(                                                                                                 \
   BOOST_PP_EXPR_IF(BOOST_PP_SEQ_ELEM(0, data), BOOST_PP_SEQ_ENUM(BOOST_PP_SEQ_ELEM(0, elem)))                       \
   ) { return caller<R(                                                                                              \
   BOOST_PP_EXPR_IF(BOOST_PP_SEQ_ELEM(0, data), BOOST_PP_SEQ_ENUM(BOOST_PP_SEQ_ELEM(1, elem)))                       \
   )>::apply(                                                                                                        \
      BOOST_PP_ENUM_PARAMS(BOOST_PP_SEQ_ELEM(0, data), BOOST_PP_SEQ_ELEM(1, BOOST_PP_SEQ_ELEM(1, data)))             \
   ); };

#define BOOST_HOLDER_METHOD_APPLY_FUNCTION(n, tag)                               \
   BOOST_PP_SEQ_FOR_EACH(BOOST_HOLDER_METHOD_APPLY_FUNCTION_PARAM_JOINT, (n)(tag), BOOST_HOLDER_METHOD_APPLY_FUNCTION_PARAMS(n, tag))


template<
   typename derived_t,
   typename processor_t = detail::rule::processor,
   typename caster_t = detail::rule::caster,
   typename missing_t = detail::rule::missing
> struct methods_base {

   typedef caster_t caster_type;

   template<typename index_t, typename data_t>
   class links {
   public:
      typedef index_t key_type;
      typedef data_t mapped_type;
      data_t& operator[](index_t index) {
         if (index < data_.size()) return data_[index];
         data_.resize(index+1);
         return data_[index];
      };
   private:
      std::vector<data_t> data_;
   };

   template<typename trampoline_t>
   class method {
   public:
      typedef const unsigned int id_type;
      typedef trampoline_t trampoline_type;
      //typedef std::map<id_type, method> methods_type;
      //typedef boost::unordered_map<id_type, method> methods_type;
      typedef links<id_type, method> methods_type;
      method() : trampoline_(), methods_() {};
      template<typename T>
      method& find(T& target) { return caster_type::find(*this, target); };
      template<typename T>
      method& find() { return caster_type::find<T>(*this); };
      template<typename T>
      method& setup(trampoline_type value) {
         method& m(find<T>());
         m.setup(value);
         return m;
      };
      method& setup(trampoline_type value) { trampoline_ = value; return *this; };
      trampoline_type trampoline() { return trampoline_; };
   private:
      trampoline_type trampoline_;
      methods_type methods_;
      friend caster_type;
   };

   template<typename Signature>
   struct caller;

#  define METHODS_MACRO(z, n, _)                                                                                     \
   template<                                                                                                         \
      typename R BOOST_PP_COMMA_IF(n)                                                                                \
      BOOST_PP_ENUM_PARAMS(n, typename T)                                                                            \
   > struct caller ## n {                                                                                            \
      typedef typename missing_t::main<R> missing_type;                                                              \
      typedef typename processor_t::main<R> processor_type;                                                          \
      BOOST_PP_REPEAT(n, BOOST_HOLDER_METHOD_REF_ARG, T)                                                             \
      typedef R(*trampoline_type)(BOOST_PP_ENUM_PARAMS(n, RT));                                                      \
      typedef method<trampoline_type> method_type;                                                                   \
      static method_type& method() { static method_type r; return r; };                                              \
      template<BOOST_PP_ENUM_PARAMS(n, typename A) BOOST_PP_COMMA_IF(n) typename processor_t>                        \
      struct trampoline {                                                                                            \
         typedef processor_t processor_type;                                                                         \
         static processor_type& processor() { static processor_type r; return r; };                                  \
         static R call(BOOST_PP_ENUM_BINARY_PARAMS(n, RT, a)) {                                                      \
            return processor()( BOOST_PP_ENUM(n, BOOST_HOLDER_METHOD_CASTED_ARGS, (A)(a)) );                         \
          };                                                                                                         \
      };                                                                                                             \
      static missing_type& missing() { static missing_type r; return r; };                                           \
   public:                                                                                                           \
      template<BOOST_PP_ENUM_PARAMS(n, typename A) BOOST_PP_COMMA_IF(n) typename processor_t>                        \
      static bool entry() {                                                                                          \
         trampoline_type t(&trampoline<                                                                              \
            BOOST_PP_ENUM_PARAMS(n, A) BOOST_PP_COMMA_IF(n) processor_t                                              \
         >::call);                                                                                                   \
         method().setup(t);                                                                                          \
         BOOST_PP_REPEAT(n, BOOST_HOLDER_METHOD_TRAMPOLINE, (n) (A))                                                 \
         return true;                                                                                                \
      };                                                                                                             \
      BOOST_HOLDER_METHOD_ENTRY(n)                                                                                   \
      BOOST_HOLDER_METHOD_ENTRY_PROCESSOR(n)                                                                         \
      static R apply(BOOST_PP_ENUM_BINARY_PARAMS(n, RT, a)) {                                                        \
         trampoline_type t(method() BOOST_PP_REPEAT(n,BOOST_HOLDER_METHOD_TRAMPOLINE_VALUE_FINDER,a).trampoline());  \
         if (!t) return missing()(BOOST_PP_ENUM_PARAMS(n, a));                                                       \
         return t(BOOST_PP_ENUM_PARAMS(n, a));                                                                       \
      };                                                                                                             \
   };                                                                                                                \
   template<typename R                                                                                               \
      BOOST_PP_EXPR_IF(n, BOOST_PP_COMMA() BOOST_PP_ENUM_PARAMS(n, typename A))                                      \
   > struct caller<R(BOOST_PP_ENUM_PARAMS(n, A))>                                                                    \
      : caller ## n <R BOOST_PP_EXPR_IF(n, BOOST_PP_COMMA() BOOST_PP_ENUM_PARAMS(n, A))                              \
   > {};                                                                                                             \
   BOOST_HOLDER_METHOD_APPLY_FUNCTION(n, (T)(t))

   BOOST_PP_REPEAT(BOOST_HOLDER_METHOD_MAX_ARGS, METHODS_MACRO, nil)

};

struct methods : public methods_base<methods> {};


};
};


#endif
