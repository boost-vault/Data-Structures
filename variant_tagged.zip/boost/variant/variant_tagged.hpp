#ifndef BOOST_VARIANT_TAGGED_HPP
#define BOOST_VARIANT_TAGGED_HPP

#include <boost/variant.hpp>
#include <boost/mpl/at.hpp>
#ifdef USE_FUSION_PAIR_MAP
#include <boost/fusion/support/intkey_val_pair_map.hpp>
#endif

namespace boost {

  template
  < typename Types
  , typename TagType=unsigned
  >
  struct
variant_tagged
#ifndef USE_FUSION_PAIR_MAP
: public
  boost::make_variant_over
  < Types
  >::type
#else
: public
  boost::make_variant_over
  < typename
    fusion::intkey_val_pair_map
    < Types
    , TagType
    >::type
  >::type
#endif
{
        typedef
      variant_tagged
      < Types
      , TagType
      >
    my_type
    ;
        typedef
    #ifndef USE_FUSION_PAIR_MAP
      Types
    #else
      typename
      fusion::intkey_val_pair_map
      < Types
      , TagType
      >::type
    #endif
    variants_type
    ;
        typedef
        typename
      boost::make_variant_over<variants_type>::type
    super_type
    ;
      template
      < TagType TagVal
      >
      struct
    at_type
    : boost::mpl::at_c<Types,TagVal>
    {
    };
  #ifdef USE_FUSION_PAIR_MAP
      template
      < TagType TagVal
      >
      struct
    pair_type
    {
        typedef mpl::integral_c<TagType,TagVal> key_type;
        typedef typename at_type<TagVal>::type val_type;
        typedef fusion::pair<key_type,val_type> type;
    };
  #endif
      template
      < TagType TagVal
      >
        static
      my_type
    _
      ( typename  at_type<TagVal>::type const& a_val
      )
    {
      #ifndef USE_FUSION_PAIR_MAP
        return variant_tagged(super_type(a_val),TagVal);
      #else
        typename pair_type<TagVal>::type a_pair(a_val);
        return variant_tagged(super_type(a_pair));
      #endif
    }
    variant_tagged
      ( my_type const& a
      )
    : super_type(static_cast<super_type const&>(a))
  #ifndef USE_FUSION_PAIR_MAP
    , my_tag(a.my_tag)
  #endif
    {}
      TagType
    tag(void)const
    {
      #ifndef USE_FUSION_PAIR_MAP
        return my_tag;
      #else
        return TagType(super_type::which());
      #endif
    }
      template
      < TagType TagVal
      >
      typename at_type<TagVal>::type
    get(void)const
    {
      #ifndef USE_FUSION_PAIR_MAP
        typedef typename at_type<TagVal>::type result_type;
      #else
        typedef typename pair_type<TagVal>::type result_type;
      #endif
        super_type const&me=*this;
        result_type a_result=boost::get<result_type>(me);
      #ifndef USE_FUSION_PAIR_MAP
        return a_result;
      #else
        return a_result.second;
      #endif
    }
 private:
    variant_tagged
      ( super_type const& a_super
    #ifndef USE_FUSION_PAIR_MAP
      , TagType a_tag
    #endif
      )
    : super_type(a_super)
    #ifndef USE_FUSION_PAIR_MAP
    , my_tag(a_tag)
    #endif
    {}
  #ifndef USE_FUSION_PAIR_MAP
      TagType
    my_tag
    ;
  #endif
    
};

} // namespace boost

#endif// BOOST_VARIANT_TAGGED_HPP
