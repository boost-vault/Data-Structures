#ifndef BOOST_FUSION_INTKEY_PAIR_MAP_HPP
#define BOOST_FUSION_INTKEY_PAIR_MAP_HPP
#include <boost/fusion/support/pair.hpp>
#include <boost/mpl/size.hpp>
#include <boost/mpl/range_c.hpp>
#include <boost/mpl/copy.hpp>
#include <boost/mpl/back_inserter.hpp>
#include <boost/mpl/vector_c.hpp>
#include <boost/mpl/transform.hpp>
namespace boost 
{ namespace fusion
  {
      template
      < typename Values
      , typename IntegralKeys=unsigned
      >
      struct
    intkey_val_pair_map
    /**@brief
     *  Make a sequence of fusion::pairs
     *  where 1st element is mpl::integral_c<IntegralKeys,Key>
     *  for some Key, and 2nd element is mpl::at_c<Values,Key>::type
     */
    : mpl::transform
      < typename
        mpl::copy
        < mpl::range_c
          < IntegralKeys
          , 0
          , mpl::size<Values>::type::value
          >
        , mpl::back_inserter
          < mpl::vector_c<IntegralKeys>
          >
        >::type
      , Values
      , fusion::pair
        < mpl::_1
        , mpl::_2
        >
      >
    {
    };
    
  }
}  
#endif
