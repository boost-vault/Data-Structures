//Purpose:
//  Demonstrate how variant can be used to implement
//  tagged union.
//Motivation:
//  The variant_tagged<vector<T1,T2,...,Tn> > can be used
//  in spirit for non-string processing.  For example, it
//  could be used as a generalization of the atom in:
/*
http://www.boost-consulting.com/vault/index.php?action=downloadfile&filename=calc_plain_tag_union_tok.zip&directory=Strings%20-%20Text%20Processing&
 */
//  as it appeared on 2007-12-05. The following post:
/*
http://article.gmane.org/gmane.comp.parsers.spirit.general/12646
 */
//  with Subject: Re: Parsing of non-strings,
//  provides a use-case for such non-string processing:

#define USE_FUSION_PAIR_MAP
#include <boost/variant/variant_tagged.hpp>
#include <boost/mpl/vector.hpp> 
#include <boost/test/minimal.hpp>
  template
  < unsigned Index
  >
  struct
type_i
{
      char
    my_stor[100+Index*10]
    ;
    type_i(void)
    : my_i(Index)
    {}
      unsigned
    my_i
    ;
};
  unsigned const
i0=0
;
#define NO_DUPTYPE
  unsigned const
i1=i0
#ifdef NO_DUPTYPE
  +1
#endif
;

  template
  < bool Dif
  >
  void
run_test  
  ( void
  )
{
    std::cout<<"----- begin test -----------\n";
    unsigned const injected_index=unsigned(Dif);
    std::cout<<"injected_index="<<injected_index<<"\n";
    typedef type_i<injected_index> injected_type;
    unsigned const injected_tag=0;
    std::cout<<"injected_tag="<<injected_tag<<"\n";
        typedef
      boost::variant_tagged
      < boost::mpl::vector
        < injected_type
        , type_i<0>
        >
      >
    var_type
    ;
    injected_type injected_value;
    var_type a_var(var_type::template _<injected_tag>(injected_value));
  #if 1
    std::cout<<"which="<<a_var.which()<<"\n";
    std::cout<<"tag="<<a_var.tag()<<"\n";
    BOOST_CHECK(injected_tag == a_var.tag());
    BOOST_CHECK(injected_tag == unsigned(a_var.which()));
    injected_type projected_value=a_var.template get<injected_tag>();
    std::cout<<"projected_value.my_i="<<projected_value.my_i<<"\n";
    BOOST_CHECK(projected_value.my_i == injected_value.my_i);
  #endif
}    
  int
test_main(int,char**)
{
  #ifdef USE_FUSION_PAIR_MAP
    std::cout<<"#define USE_FUSION_PAIR_MAP\n";
  #else
    std::cout<<"#undef  USE_FUSION_PAIR_MAP\n";
  #endif
    run_test<false>();
    run_test<true>();
    return 0;
}
