#ifndef BOOST_ALIGNED_TYPES_INCLUDED
#define BOOST_ALIGNED_TYPES_INCLUDED
//Purpose:
//  Given a sequence of types composing a composite
//  of the following "kinds":
//    variant
//    tuple_aligned
//    tuple_packed
//  calculates aligned_storage for the composite and
//  also calculates offsets into the aligned_storage for
//  components of that composites if its kind is one of:
//    tuple_aligned
//    tuple_packed
#include <cstddef>
#include <boost/mpl/fold.hpp>
#include <boost/mpl/size.hpp>
#include <boost/math/common_factor_ct.hpp>
#include <boost/type_traits/alignment_of.hpp>
#include <boost/aligned_storage.hpp>

namespace boost
{
namespace composite_kinds
{
    struct variant        ; //kind for union of components, like c++ union.
    struct tuple_aligned  ; //kind for tuple of components, like c++ struct.
    struct tuple_packed   ; //kind for "packed" tuple, i.e. no alignments(to save space).

};
namespace detail_aligned_types
{
  template
  < std::size_t Left
  , std::size_t Right
  >
  struct
compatible_alignment
/**@brief
 *  "Metafunction" returning alignment which is compatible with the 
 *   metafunction argument alignments, Left and Right.
 *
 *  The real reason why this template was created instead of directly using
 *  static_lcm was to provide the documentation shown below which justifies
 *  static_lcm use.
 */
{
        static
      std::size_t const
    value
    = ::boost::math::static_lcm
      < (unsigned long)Left
      , (unsigned long)Right
      >::value
      //The use of static_lcm is based on the statement:
      //
      //  N is the least common multiple of all Alignments
      //
      //in paragraph 1 on page 10 of:
      //
      //  http://www.open-std.org/jtc1/sc22/wg21/docs/papers/2007/n2165.pdf
      //
      //AFAICT, the reason lcm is used instead of just taking the
      //maximum:
      //
      //  Left>Right?Left:Right
      //
      //is to account for "Extended alignments" mentioned in paragraph 3 
      //on page 3 of the n2165 reference mentioned above.  OTOH, if only
      //"Fundamental alignments" are used (which, I assume, are the
      //"static alignments;powers of 2" in paragraph 4 on page 5 of:
      //
      //  http://www.open-std.org/JTC1/SC22/WG21/docs/papers/2006/n2140.pdf
      //
      //) then simply using max instead of lcm would work.
    ;
};
  
  template
  < class CompositeKind //some struct declared in composite_kinds namespace
  , class Head
  , class Tail
  >
  struct 
composite_partial
/**@brief
 *  Calculates:
 *    size_part = storage size
 *    alignment_part = alignment requirements
 *  of a composite starting with an element of type, Head, and followed
 *  by elements in a composite whose size_part and alignment_part are:
 *    Tail::size_part
 *    Tail::alignment_part
 */
;
  struct 
composite_start
/**@brief
 *  Start of fold for creating folds of composite_partial's.
 */
{
        static
      std::size_t const
    size_part
    = 0
    /**@brief
     *  size of an 'empty' composite.
     */
    ;
        static
      std::size_t const
    alignment_part
    = 1
    /**@brief
     *  alignment requirements of all components in
     *  an 'empty' composite.
     */
    ;
};

  template
  < typename Head
  , typename Tail
  >
  struct 
composite_partial
  < composite_kinds::variant
  , Head
  , Tail
  >
{
        static
      std::size_t const
    size_part
    = Tail::size_part > sizeof(Head)
    ? Tail::size_part
    : sizeof(Head)
    ;
        static
      std::size_t const
    alignment_one
    = ::boost::alignment_of<Head>::value
    ;
        static
      std::size_t const
    alignment_part
    = compatible_alignment
      < alignment_one
      , Tail::alignment_part
      >::value
    ;
};

  template
  < typename Head
  , typename Tail
  >
  struct 
composite_partial
  < composite_kinds::tuple_packed
  , Head
  , Tail
  >
{
        static
      std::size_t const
    alignment_part
    = Tail::alignment_part//=composite_start::alignment_part
    ;
        static
      std::size_t const
    size_part
    = Tail::size_part
    + sizeof(Head)
    ;
};

  template
  < std::size_t Offset
  , std::size_t Alignment
  >
  struct
next_aligned_offset
{
        static
      std::size_t const
    remainder
    = Offset%Alignment
    ;
        static
      std::size_t const
    value
    = remainder == 0
    ? Offset
    : Offset+(Alignment-remainder)
    //value is minimum value > Offset such that
    //value%Alignment == 0
    ;
    
};  

  template
  < class Head
  , class Tail
  >
  struct 
composite_partial
  < composite_kinds::tuple_aligned
  , Head
  , Tail
  >
/**@brief  
 *  In combination with composite_size<,>(see below), implements method described 
 *  in aligned_struct_offsets.txt 
 *  on 10 Apr 2007
 *  at http://boost-consulting.com/vault/index.php?directory=variadic_templates
 */
{
        static
      std::size_t const
    alignment_one
    = ::boost::alignment_of<Head>::value
    ;
        static
      std::size_t const
    alignment_part
    = compatible_alignment
      < Tail::alignment_part
      , alignment_one
      >::value
    ;
        static
      std::size_t const
    size_part
    = next_aligned_offset
      <   Tail::size_part 
        + sizeof(Head)
      , alignment_one
      >::value
    ;
};

}//exit detail_aligned_types namespace

  template
  < class Kind
  , class Sequence
  >
  struct
aligned_types
{
        typedef
        typename
      mpl::fold
      < Sequence
      , detail_aligned_types::composite_start
      , detail_aligned_types::composite_partial
        < Kind
        , mpl::arg<2>
        , mpl::arg<1>
        >
      >::type
    composite_type
    ;
        static
      std::size_t const
    alignment_value
    = composite_type::alignment_part
    ;
        typedef
        typename
      ::boost::aligned_storage
      < composite_type::size_part
      , alignment_value
      >::type
    type
    ;
};
   
namespace detail_aligned_types
/**@brief
 *  This section defines composite_at, a template
 *  for accessing the different parts of composite_partial's.
 */
{

  template
  < typename CompositePartial
  , unsigned Index
  >
  struct
composite_at
;  
//recurse through composite_at components:
  template
  < class Kind
  , class Head
  , class Tail
  , unsigned Index
  >
  struct
composite_at
  < composite_partial
    < Kind
    , Head
    , Tail
    >
  , Index
  >
: composite_at
  < Tail
  , Index-1
  >
{
        typedef
      composite_at
    type
    ;    
};
//terminate composite_at recursion:
  template
  < class Kind
  , class Head
  , class Tail
  >
  struct
composite_at
  < composite_partial
    < Kind
    , Head
    , Tail
    >
  , 0
  >
: composite_partial
  < Kind
  , Head
  , Tail
  >
{    
        typedef
      composite_at
    type
    ;    
};  

  template
  <
  >
  struct
composite_at
  < composite_start
  , 0
  >
: composite_start
{
};

}//exit detail_aligned_types namespace
}//exit boost namespace
#include <boost/mpl/at.hpp>
namespace boost
{
namespace mpl
{
  template
  < class Kind
  , class Sequence
  , long Index
  >
  struct
at_c
  < boost::aligned_types
    < Kind
    , Sequence
    >
  , Index
  >
{
        typedef
        typename
      boost::aligned_types
      < Kind
      , Sequence
      >::composite_type
    composite_type
    ;
        typedef
        typename
      boost::detail_aligned_types::composite_at    
      < composite_type
      , mpl::size<Sequence>::type::value-Index
      >::type
    type
    ;
}
; 
}};
#endif
