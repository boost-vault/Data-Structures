import sys
impl = eval(sys.argv[1])
vard = sys.argv[2]
if impl == 1:
  print vard+" -std=gnu++0x -DCXX0X_VARIADIC_TEMPLATES -DBOOST_USE_MPL_VARIADIC_TEMPLATES"
