#!/usr/bin/env python

import sys, re, functools, string

#regular expression indices:
test_size_re=0 #test size
total_re=test_size_re+1 #total time
impl_re=total_re+1 #implementation value
num_res=impl_re+1 #number of regular expressions


all_re = [ re.compile("^plot_x:VARIANT_TEST_SIZE=([0-9]+)")
         , re.compile("^ TOTAL[ ]+:[ ]+([^ ]+)")
         , re.compile("^plot_impl:VARIANT_TEST_IMPL=([0-9]+)")
         ]

#implementation indices:
clo_impl=0 #CLoPtrVariant
oom_impl=clo_impl+1 #one_of_maybe
var_impl=oom_impl+1 #boost::variant
num_impls=var_impl+1 #number of implementations

xs = []
ys = {}

y_key=None
x_max=-1
re_indices = range(num_res)
for line in sys.stdin.readlines():
  for re_index in re_indices:
    found = all_re[re_index].search(line)
    if found:
      val = eval(found.group(1))
      if re_index == impl_re:
        y_key=val
        if not(ys.has_key(y_key)):
          ys[y_key]=[]
      elif re_index == total_re:
        ys[y_key].append(val)
      elif re_index == test_size_re:
        if val > x_max:
          x_max=val
          xs.append(val)
      break

#print "xs=",xs
#print "ys=",ys
print "TOTAL compile time(secs)"
col_ttl_txt = ['TestSize','CLoPtrVariant','OneOfMaybe','boost::variant']
y_keys = ys.keys()
y_indices=range(len(y_keys))
print "%s " % col_ttl_txt[0],
for i in y_keys:
  print "%s " % col_ttl_txt[i+1],
print #end-line

x_num_fmt = "%"+`len(col_ttl_txt[0])`+"d "
y_width = map(len,col_ttl_txt[1:])
y_num_fmt = functools.reduce((lambda z,x:z+["%"+`x`+".3f "]),y_width,[])
row_indices = range(len(xs))
for irow in row_indices:
  print x_num_fmt % xs[irow],
  for icol in y_keys:
    print y_num_fmt[icol] % ys[icol][irow],
  print #eod-line

