//ChangeLog:
//  2011-01-07.1919CST
//    copied from attachment to:
//      http://article.gmane.org/gmane.comp.lib.boost.user/64988
//  2011-01-07.22309CST
//    Added one_of_maybe code and macro to switch beteen
//    that and boost::variant implementations.
//

#include "variant_test_impl_macros.hpp"

#ifndef USE_SHARED_PTR
#define USE_SHARED_PTR 1
#endif

#ifndef VARIANT_TEST_SIZE
#define VARIANT_TEST_SIZE 2
#endif

#ifndef VARIANT_TEST_IMPL
#define VARIANT_TEST_IMPL VARIANT_TEST_CLOPTR
#endif

#define MACRO_SHOW_VALUE(A_MACRO,A_VALUE) A_MACRO "=" #A_VALUE
#define MACRO_SHOW(A_MACRO) MACRO_SHOW_VALUE(#A_MACRO,A_MACRO)

#pragma message MACRO_SHOW(VARIANT_TEST_SIZE)
#pragma message MACRO_SHOW(USE_SHARED_PTR)
#pragma message MACRO_SHOW(VARIANT_TEST_IMPL)

#if USE_SHARED_PTR
  #include <boost/shared_ptr.hpp>
#endif

#if VARIANT_TEST_ONE_OF_MAYBE == VARIANT_TEST_IMPL
  #include <boost/composite_storage/pack/container_one_of_maybe.hpp>
#elif VARIANT_TEST_BOOST == VARIANT_TEST_IMPL
  #include <boost/mpl/vector.hpp>
  #include <boost/variant/variant.hpp>
  #include <boost/variant/apply_visitor.hpp>
  #include <boost/variant/static_visitor.hpp>
#elif (VARIANT_TEST_CLOPTR == VARIANT_TEST_IMPL) && (USE_SHARED_PTR == 1)
  #include "CLoPtrVariant.hpp"
  #include <boost/mpl/vector.hpp>
#else
  #pragma message "invalid VARIANT_TEST_IMPL"
#endif

#include <boost/preprocessor/iteration/local.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/preprocessor/enum.hpp>


template<unsigned>
class C { public: int i; };

#if USE_SHARED_PTR
  #define VARIANT_ARG(z, n, data) boost::shared_ptr<C<n> > /**/
#else
  #define VARIANT_ARG(z, n, data) C<n> /**/
#endif
  
#if VARIANT_TEST_ONE_OF_MAYBE == VARIANT_TEST_IMPL
      typedef 
    boost::composite_storage::pack::container
    < boost::composite_storage::tags::one_of_maybe
    , boost::mpl::integral_c<unsigned,0>
    , BOOST_PP_ENUM(VARIANT_TEST_SIZE, VARIANT_ARG, ~)
    >
  v_t;
#elif VARIANT_TEST_BOOST == VARIANT_TEST_IMPL
      typedef 
    boost::mpl::vector<BOOST_PP_ENUM(VARIANT_TEST_SIZE, VARIANT_ARG, ~)> 
  Mplv_t;
      typedef 
    boost::make_variant_over<Mplv_t>::type 
  v_t;
#elif VARIANT_TEST_CLOPTR == VARIANT_TEST_IMPL
      typedef 
    boost::mpl::vector<BOOST_PP_ENUM(VARIANT_TEST_SIZE, VARIANT_ARG, ~)> 
  Mplv_t;
      typedef 
    Layout::make_variant_over<Mplv_t>::type 
  v_t;
#endif  

void foo(const v_t& v)
{
//C: Copy variant using assignment operator
  v_t v2;
  v2 = v;
} 

int main()
{
  v_t v;
#if VARIANT_TEST_ONE_OF_MAYBE == VARIANT_TEST_IMPL
  VARIANT_ARG(~,0,~) c0;
  v.inject<0>(c0);
#endif
  foo(v);
  return 0;
}

