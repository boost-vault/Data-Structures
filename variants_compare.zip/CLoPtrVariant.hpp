//ChangeLog:
//  2011-01-27.1900
//    Copied from post with headers:
/*
From: Paul <peebor@gmail.com>
Newsgroups: gmane.comp.lib.boost.user
Subject: Re: large variant performance compared (50 elements)
Date: Thu, 27 Jan 2011 20:19:08 +0100
Lines: 374
 */
//====================
#include <boost/type_traits/is_same.hpp>
#include <boost/type_traits/is_base_of.hpp>
#include <boost/mpl/is_sequence.hpp>
#include <boost/mpl/less.hpp>
#include <boost/mpl/size.hpp>
#include <boost/mpl/at.hpp>
#include <boost/mpl/find.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/static_assert.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/preprocessor/iteration/local.hpp>

namespace Layout
{
  template<typename Typelist>
  class CLoPtrVariant
  {
  public:
    CLoPtrVariant()
      : m_uiSelect(0)
    {
      // precondition assertions
      BOOST_STATIC_ASSERT((boost::mpl::is_sequence<Typelist>::value));
    }

    template<typename Type>
    CLoPtrVariant(const boost::shared_ptr<Type>& rspValue)
    {
      assign(rspValue);
    }

    CLoPtrVariant(const CLoPtrVariant& rOperand)
    {
      m_spSelect = rOperand.m_spSelect;
      m_uiSelect = rOperand.m_uiSelect;
    }

    template<typename Typelist2>
    CLoPtrVariant(const CLoPtrVariant<Typelist2>& rOperand)
    //Forward declare since body uses template's not yet
    //declared.
    ;

    template<typename Type>
    CLoPtrVariant& operator=(const boost::shared_ptr<Type>& rspValue)
    {
      assign(rspValue);
      return *this;
    }

    template<typename Type>
    CLoPtrVariant& operator=(boost::shared_ptr<Type>& rspValue)
    {
      assign(rspValue);
      return *this;
    }

    bool operator<(const CLoPtrVariant& rRhs) const
    {
      if(m_uiSelect != rRhs.m_uiSelect)
      {
        return (m_uiSelect < rRhs.m_uiSelect);
      }
      else
      {
        return (m_spSelect < rRhs.m_spSelect);
      }
    }

    bool operator==(const CLoPtrVariant& rRhs) const
    {
      return (m_uiSelect == rRhs.m_uiSelect && m_spSelect == rRhs.m_spSelect);
    }

    bool operator!=(const CLoPtrVariant& rRhs) const
    {
      return !(*this == rRhs);
    }

    template<typename WhichType, typename VisitorType>
    typename VisitorType::result_type apply_visitor(VisitorType& rVisitor, boost::mpl::false_ /*unrolled*/) const
    {
      BOOST_ASSERT(false); //Should never assert here; only meant to stop recursion at the end of the typelist
      return typename VisitorType::result_type();
    }

    template<typename WhichType, typename VisitorType>
    typename VisitorType::result_type apply_visitor(VisitorType& rVisitor, boost::mpl::true_ /*unrolled*/) const
    {
      switch (m_uiSelect)
      {
#ifdef BOOST_PP_LOCAL_ITERATE
#define BOOST_PP_LOCAL_MACRO(n) \
      case (WhichType::value + n): \
        return apply_visitor_impl<VisitorType, boost::mpl::int_<WhichType::value + n> >(rVisitor, typename boost::mpl::less<boost::mpl::int_<WhichType::value + n>, typename boost::mpl::size<Typelist>::type>::type()); \
        break;
#define BOOST_PP_LOCAL_LIMITS (0, 10)
#include BOOST_PP_LOCAL_ITERATE()
#endif //BOOST_PP_LOCAL_ITERATE
      default:
        typedef typename boost::mpl::int_<WhichType::value + 10> next_which_t;
        return apply_visitor<next_which_t>
         ( rVisitor
         , typename boost::mpl::less
           < next_which_t
           , typename boost::mpl::size<Typelist>::type
           >::type()
         );
      }
    }

    size_t GetWhich() const
    {
      return m_uiSelect;
    }

    void SetWhich(size_t which)
    {
      BOOST_ASSERT(!m_spSelect);
      m_uiSelect = which;
    }

  private:
    template<typename Type>
    void assign(const boost::shared_ptr<Type>& rspValue)
    {
      typedef typename boost::mpl::find<Typelist, boost::shared_ptr<Type> >::type pos_t;
      typedef typename boost::mpl::end<Typelist>::type end_t;
      BOOST_STATIC_ASSERT((!boost::is_same<pos_t, end_t>::value));
      m_spSelect = boost::static_pointer_cast<void>(rspValue);
      m_uiSelect = pos_t::pos::value;
    }

    template<typename VisitorType, typename IndexType>
    inline typename VisitorType::result_type apply_visitor_impl(VisitorType& rVisitor, boost::mpl::true_ /*is_unrolled_t*/) const
    {
      typedef typename boost::mpl::at<Typelist, IndexType>::type::value_type value_t;
         boost::shared_ptr<value_t> 
       spc(boost::static_pointer_cast<value_t>(m_spSelect))
       //Need this instead of creating in call to rVisitor
       //because g++ apparently doesn't convert the value
       //to a reference; hence, there's no matching:
       //  rVisitor::operator()(share_ptr<value_type>).
       //Instead, there's just:
       //  rVisitor::operator()(share_ptr<value_type>&).
       ;
       return rVisitor(spc);
    }

    template<typename VisitorType, typename IndexType>
    inline typename VisitorType::result_type apply_visitor_impl(VisitorType& rVisitor, boost::mpl::false_ /*is_unrolled_t*/) const
    {
      //Should never be here at runtime; only required to block code generation that deref's the sequence out of bounds
      BOOST_ASSERT(false);
      return typename VisitorType::result_type();
    }

  private:
    boost::shared_ptr<void> m_spSelect;
    size_t m_uiSelect;
  };

  //Helper function-template to construct the variant type
  template<typename Typelist>
  struct make_variant_over
  {
  public:
    typedef CLoPtrVariant<Typelist> type;
  };

  //Unary visitation
  template<typename Visitor, typename Visitable>
  inline typename Visitor::result_type apply_visitor(const Visitor& visitor, Visitable& visitable)
  {
    return visitable.apply_visitor<boost::mpl::int_<0> >(visitor, boost::mpl::true_());
  }

  template<typename Visitor, typename Visitable>
  inline typename Visitor::result_type apply_visitor(Visitor& visitor, Visitable& visitable)
  {
    return visitable.apply_visitor<boost::mpl::int_<0> >(visitor, boost::mpl::true_());
  }

  //Binary visitation
  template<typename Visitor, typename Value1>
  class CBinaryUnwrap2
  {
  public:
    typedef typename Visitor::result_type result_type;

  private:
    Visitor& visitor_;
    Value1& value1_;

  public:
    CBinaryUnwrap2(Visitor& visitor, Value1& value1)
      : visitor_(visitor)
      , value1_(value1)
    {
    }

  public:
    template <typename Value2>
    result_type operator()(Value2& value2)
    {
      return visitor_(value1_, value2);
    }
  };

  template <typename Visitor, typename Visitable2>
  class CBinaryUnwrap1
  {
  public:
    typedef typename Visitor::result_type result_type;

  private:
    Visitor& visitor_;
    Visitable2& visitable2_;

  public:
    CBinaryUnwrap1(Visitor& visitor, Visitable2& visitable2)
      : visitor_(visitor)
      , visitable2_(visitable2)
    {
    }

  public:
    template<typename Value1>
    result_type operator()(Value1& value1)
    {
      CBinaryUnwrap2<Visitor, Value1> unwrapper(visitor_, value1);
      return apply_visitor(unwrapper, visitable2_);
    }
  };

  template<typename Visitor, typename Visitable1, typename Visitable2>
  inline typename Visitor::result_type apply_visitor(const Visitor& visitor, Visitable1& visitable1, Visitable2& visitable2)
  {
    //in 3 stappen doen; eerst visitable1 en visitable2 meegeven en daarna visit op visitable2 doen en resultaat v/d eerste meegeven, dan visit op de laatste
    Layout::CBinaryUnwrap1<const Visitor, Visitable2> unwrapper(visitor, visitable2);
    return apply_visitor(unwrapper, visitable1);
  }

  template<typename Visitor, typename Visitable1, typename Visitable2>
  inline typename Visitor::result_type apply_visitor(Visitor& visitor, Visitable1& visitable1, Visitable2& visitable2)
  {
    Layout::CBinaryUnwrap1<Visitor, Visitable2> unwrapper(visitor, visitable2);
    return apply_visitor(unwrapper, visitable1);
  }

  //Base class for visitor classes
  template<typename R = void>
  class static_visitor
  {
  public:
    typedef R result_type;

  protected:
    // for use as base class only
    static_visitor() { }
    ~static_visitor() { }
  };

  template<typename Base, typename Derived>
  struct is_base_of_smartptr
    : boost::is_base_of<typename Base::value_type, typename Derived::value_type>
  {
  };

  //Convert variant types
  template<typename Typelist>
  class CConvertVariant
    : public static_visitor<>
  {
  public:
    CConvertVariant(CLoPtrVariant<Typelist>& rVariant)
      : m_rVariant(rVariant)
    {
    }

    template<typename T>
    void operator()(boost::shared_ptr<T>& rValue) //T is not const to match the variant bounded types
    {
          typedef typename 
        boost::mpl::find_if
        < Typelist
        , is_base_of_smartptr
          < boost::mpl::_1
          , boost::shared_ptr<T> 
          > 
        >::type 
      pos_t;
      typedef typename boost::mpl::end<Typelist>::type end_t;
      typedef typename boost::is_same<pos_t, end_t>::type not_convertible;
      typedef typename boost::mpl::not_<not_convertible>::type yes_convertible;
      BOOST_MPL_ASSERT_MSG(yes_convertible::value,SHARED_PTR_OF_T_NOT_IN_BOUNDED_TYPES,(T,Typelist));
      assign_variant<pos_t>(rValue,yes_convertible());
    }

  private:
       template
       < typename Pos
       , typename Type
       >
     void assign_variant
       ( boost::shared_ptr<Type>& rValue
       , boost::mpl::true_//yes convertible
       ) 
     {
       typedef typename boost::mpl::deref<Pos>::type::value_type value_t;
       m_rVariant =  boost::static_pointer_cast<value_t>(rValue);
     }

       template
       < typename Pos
       , typename Type
       >
     void assign_variant
       ( boost::shared_ptr<Type>& rValue
       , boost::mpl::false_//not convertible
       ) 
       //Never called because BOOST_MPL_ASSERT_MSG in caller
       //should prevent compilation.
       //
       //The purpose of this seemingly useless declaration is to
       //avoid redundant compiler error messages if the body
       //of the other assign_variant were put inside the caller.
       //In that case, when the BOOST_MPL_ASSERT_MSG failed,
       //there would be compiler error messages about deref<Pos>::type::value_type
       //since Pos would be at the end of Typelist.
     ;
    CLoPtrVariant<Typelist>& m_rVariant;
  };

   template<typename Typelist>
     template<typename Typelist2>
   CLoPtrVariant<Typelist>::     
     CLoPtrVariant(const CLoPtrVariant<Typelist2>& rOperand)
     {
       CConvertVariant<Typelist> convert(*this);
       Layout::apply_visitor(convert, rOperand);
     }

  //Delayed visitation (std algorithm support)
  template<typename VisitorType>
  class CVisitDelayed
  {
  public:
    typedef typename VisitorType::result_type result_type;

  private:
    VisitorType& visitor_;

  public:
    explicit CVisitDelayed(VisitorType& visitor)
      : visitor_(visitor)
    {
    }

  public:
    //Unary
    template<typename Visitable>
    result_type operator()(Visitable& visitable)
    {
      return apply_visitor(visitor_, visitable);
    }

    //Binary
    template<typename Visitable1, typename Visitable2>
    result_type operator()(Visitable1& visitable1, Visitable2& visitable2)
    {
      return apply_visitor(visitor_, visitable1, visitable2);
    }
  };

  template<typename VisitorType>
  inline CVisitDelayed<VisitorType> apply_visitor(VisitorType& visitor)
  {
      return CVisitDelayed<VisitorType>(visitor);
  }
}
