#Purpose:
#  Given input file, named by sys.argv[1],
#  produce a graphics file from data in the input file
#  arranged in a table of values prefixed
#  by, on separate lines:
#    name of y value
#    column names, deliminted by spaces.
#
#  Name of graphics file = name of input file
#  but with different extension reflecting
#  type of graphics file.
#
import sys, string
import scitools.filetable as ft
import numpy as np
import matplotlib.pyplot as plt

inpfile_full_name = sys.argv[1]
inpfile_fp = open(inpfile_full_name,"r")
inpfile_base_name = string.join(inpfile_full_name.split('.')[:-1],'.')
print "inpfile_base_name=",inpfile_base_name

y_label=inpfile_fp.readline()
print "y_label=",y_label
col_names_list = inpfile_fp.readline().split()
print "col_names=",col_names_list

#data:

tbl = ft.read(inpfile_fp)
inpfile_fp.close()
print "tbl=\n",tbl
tblt=tbl.transpose()
print "tbl.transpose()=\n",tblt
xd=tblt[0]
ys=tblt[1:]
print "xd=",xd
print "ys=",ys

#calculate curve fits:
fit_coeff=[np.polyfit(xd,y,2) for y in ys]
print "fit_coeff=",fit_coeff
fit_poly=[np.poly1d(c) for c in fit_coeff]
#print "fit_poly=",fit_poly

#plot:
#  following code modified from:
#    /usr/share/doc/python-matplotlib-doc/examples/api/legend_demo.py
#

fig = plt.figure()
ax = fig.add_subplot(111)
ax.set_xlabel(col_names_list[0])
ax.set_ylabel(y_label)
ax.set_title(inpfile_base_name)

#calc xf: x points at which to draw fit_poly curves.
xmin=xd[0]
xnum=len(xd)
xmax=xd[xnum-1]
xdel=(xmax-xmin)/100.0 #100.0 is just guess.  More -> smoother curve
xf=np.arange(xmin,xmax+xdel,xdel)

for i in range(len(ys)):
  pts_line=ax.plot(xd,ys[i],'x',label=col_names_list[i+1]+":pts")
  pts_color=pts_line[0].get_color()
  #print ":pts_color=",pts_color
  ax.plot(xf,fit_poly[i](xf),'-',color=pts_color)

ax.legend(loc='best')

#plt.show()
#Save figure to graphics file.
grffile_format='png'
grffile_full_name=inpfile_base_name+'.'+grffile_format
plt.savefig(grffile_full_name,format=grffile_format)
