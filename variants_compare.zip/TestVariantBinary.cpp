//ChangeLog:
//  2011-01-17.1445CST
//    copied from post with headers:
/*
From: Paul <peebor@gmail.com>
Newsgroups: gmane.comp.lib.boost.user
Subject: Re: large variant performance compared (50 elements)
Date: Mon, 17 Jan 2011 21:18:54 +0100
Lines: 66
 */
#include "variant_test_impl_macros.hpp"

#ifndef VARIANT_TEST_SIZE
#define VARIANT_TEST_SIZE 5
#endif

#ifndef VARIANT_TEST_IMPL
#define VARIANT_TEST_IMPL VARIANT_TEST_CLOPTR
#endif

#include <boost/mpl/vector.hpp>
#include <boost/mpl/at.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/test/minimal.hpp>

#if VARIANT_TEST_CLOPTR == VARIANT_TEST_IMPL
#include "CLoPtrVariant.hpp"

namespace var_impl = Layout;
#pragma message "impl=CLoPtrVariant"

#elif  VARIANT_TEST_ONE_OF_MAYBE == VARIANT_TEST_IMPL
#include <boost/composite_storage/pack/multiple_dispatch/reify_apply.hpp>
#include <boost/composite_storage/pack/multiple_dispatch/reifier_switch.hpp>
#include <boost/composite_storage/pack/container_one_of_maybe.hpp>

namespace boost
{
namespace composite_storage
{
namespace pack
{
namespace multiple_dispatch
{
namespace testing
{
  template
  < typename
  >
struct make_variant_over
;
  template
  < typename... Components
  >
struct make_variant_over
  < ::boost::mpl::vector<Components...>
  >
{
        typedef
      container
      < tags::one_of_maybe
      , mpl::integral_c<int,0>
      , Components...
      >
    type
    ;
};
  
  template
  < typename Visitor
  , typename... Visitable
  >
  typename Visitor::result_type 
apply_visitor
  ( Visitor& visitor
  , Visitable&... visitable
  )
{
    return reify_apply<reifier_switch>(visitor,visitable...);
}

   //Base class for visitor classes
   template<typename R = void>
   class static_visitor
   {
   public:
     typedef R result_type;

   protected:
     // for use as base class only
     static_visitor() { }
     ~static_visitor() { }
   };

     
}//exit testing namespace
}//exit multiple_dispatch namespace
}//exit pack namespace
}//exit composite_storage namespace
}//exit boost namespace

namespace var_impl = boost::composite_storage::pack::multiple_dispatch::testing;
#pragma message "impl=OneOfMaybe"

#elif  VARIANT_TEST_BOOST == VARIANT_TEST_IMPL
#include <boost/variant.hpp>

namespace var_impl = boost;
#pragma message "impl=boost::variant"

#endif
#include <boost/mpl/vector.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/preprocessor/repetition/enum.hpp>
#include <boost/preprocessor/iteration/local.hpp>

  class CVisitBinary
    : public var_impl::static_visitor<bool>
  {
  public:
    template<typename T, typename U>
    bool operator()(const T&, const U&) const
    {
      return false;
    }

    template<typename T>
    bool operator()(const T&, const T&) const
    {
      return true;
    }
  };

//Generate 200 types (class C1, C2, ... C200)
#define BOOST_PP_LOCAL_MACRO(n) \
  class BOOST_PP_CAT(I, n) \
  { \
  public: \
  }; \
  \
  class BOOST_PP_CAT(C, n) \
    : public BOOST_PP_CAT(I, n) \
  { \
  public: \
    int i; \
  };
#define BOOST_PP_LOCAL_LIMITS (0, VARIANT_TEST_SIZE)
#include BOOST_PP_LOCAL_ITERATE()

  template
  < typename Typelist
  >
void TestVariantBinary()
{
  typedef typename var_impl::make_variant_over<Typelist>::type variant_t;
  int const ndx1=0;
  int const ndx2=1;
  typedef typename boost::mpl::at_c<Typelist,ndx1>::type comp_type1;
  typedef typename boost::mpl::at_c<Typelist,ndx2>::type comp_type2;
  comp_type1 comp_valu1;
  comp_type2 comp_valu2;
#if VARIANT_TEST_ONE_OF_MAYBE == VARIANT_TEST_IMPL
  variant_t v1_1; v1_1.template inject<ndx1>(comp_valu1);
  variant_t v1_2; v1_2.template inject<ndx1>(comp_valu1);
  variant_t v2_1; v2_1.template inject<ndx2>(comp_valu2);
#else  
  variant_t v1_1(comp_valu1);
  variant_t v1_2(comp_valu1);
  variant_t v2_1(comp_valu2);
#endif  
#if VARIANT_TEST_CLOPTR == VARIANT_TEST_IMPL
#if 0
  //shows what happens with incompatible variants.
  var_impl::CLoPtrVariant<boost::mpl::vector<boost::shared_ptr<int> > > unbounded;
  variant_t v_test_unbounded(unbounded);
#endif
#endif
  CVisitBinary visitor;
  BOOST_CHECK( var_impl::apply_visitor(visitor, v1_1, v1_2)); //Same type
  BOOST_CHECK( var_impl::apply_visitor(visitor, v1_1, v1_1)); //Same type, same instance
  BOOST_CHECK(!var_impl::apply_visitor(visitor, v1_1, v2_1)); //Different types
}

//Generate mpl sequences
#define SHARED_PTR_C(z, n, data) boost::shared_ptr<BOOST_PP_CAT(C, n)>

typedef boost::mpl::vector<BOOST_PP_ENUM(VARIANT_TEST_SIZE, SHARED_PTR_C, 0)> MplVectorCI_t;

void test()
{
  TestVariantBinary<MplVectorCI_t>(); //2 phase visitation giving 100 paths
} 
