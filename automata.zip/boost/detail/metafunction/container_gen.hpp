// Copyright (C) 2007-2011 Cromwell D. Enage
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_DETAIL_METAFUNCTION_CONTAINER_GEN_HPP_INCLUDED
#define BOOST_DETAIL_METAFUNCTION_CONTAINER_GEN_HPP_INCLUDED

#include <deque>
#include <boost/graph/adjacency_list.hpp>

namespace boost {

#if !defined BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
    struct dequeS
    {
    };

    template <typename ValueType>
    struct container_gen<dequeS,ValueType>
    {
        typedef ::std::deque<ValueType> type;
    };
#else
    struct dequeS
    {
        template <class T>
        struct bind_
        {
            typedef ::std::deque<T> type;
        };
    };

    template <>
    struct container_selector<dequeS>
    {
        typedef dequeS type;
    };
#endif  // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
}  // namespace boost

#endif  // BOOST_DETAIL_METAFUNCTION_CONTAINER_GEN_HPP_INCLUDED

