//Purpose:
//  Demo array whose dimensions and sizes are defined at runtime.
//
#include <boost/array_stepper/array_dyn.hpp>
using namespace boost::array_stepper;
typedef array_dyn<int> ad_t;
void test(ad_t::lengths_t const& a_lengths)
{
    std::cout<<"a_lengths["<<a_lengths.size()<<"]=\n";
    for(unsigned i=0; i<a_lengths.size(); ++i)
    {
        std::cout<<"  length["<<i<<"]="<<a_lengths[i]<<"\n";
    }        
    for(unsigned dir_op=dir_fwd; dir_op<unsigned(dir_rev+1); ++dir_op)
    {
        std::cout<<"*************************\n";
        std::cout<<"dir_op="<<dir_op<<"\n";
        typedef array_dyn<int> array_t;
        array_t ai(dirs(dir_op),a_lengths);
        unsigned const size=ai.my_data.size();
        std::cout<<"my_data.size()="<<size<<"\n";
        std::cout<<"ai.offset="<<ai.offset()<<"\n";
        unsigned const value0=1000;
        for( unsigned i=0; i<size; ++i)
        {
            ai.my_data[i]=value0+i;
        }
        unsigned const rank=ai.rank();
        std::cout<<"rank="<<rank<<"\n";
        for(unsigned i=0;i<rank;++i)
        {
            std::cout<<"stride("<<i<<")="<<ai.axis_ls(i).stride()<<"\n";
            std::cout<<"length("<<i<<")="<<ai.axis_ls(i).length()<<"\n";
        }
        for(unsigned i=0; i<rank;++i)
        {
            array_t::indexs_t is(rank);
            is[i]=1;
            std::cout<<"ai.offset_at_indices";
            for(unsigned j=0; j<rank; ++j)
            {
                std::cout<<((j==0)?'(':',');
                std::cout<<' '<<is[j];
            }
            std::cout<<")="<<ai.offset_at_indexv(is)<<"\n";
        }
        std::cout<<"ai=\n";
        std::cout<<ai<<".\n";
        for(unsigned rot=1; rot<rank; ++rot)
        {
            std::cout<<"rot="<<rot<<"\n";
            ai.axis_rot(1);
            std::cout<<"ai=\n";
            std::cout<<ai<<".\n";
        }
    }
}    

int main(void)
{
    test(ad_t::lengths_t({ 2, 3, 4}));
    test(ad_t::lengths_t({-2, 3, 4}));
    test(ad_t::lengths_t({ 2,-3, 4}));
    test(ad_t::lengths_t({ 2, 3,-4}));
    return 0;
}    
