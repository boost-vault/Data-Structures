#ifndef BOOST_ARRAY_STEPPER_LENGTH_STRIDE_HPP_INCLUDED
#define BOOST_ARRAY_STEPPER_LENGTH_STRIDE_HPP_INCLUDED
namespace boost
{
namespace array_stepper
{
  template
  < typename LengthType = int
  , typename StrideType = LengthType
  >
  struct
length_stride
/**@brief
 *  Length and Stride of an array axis.
 */
{
        typedef
      LengthType
    length_t
    ;
        typedef
      StrideType
    stride_t
    ;
 private:    
      length_t
    my_length
      /**@brief
       *  Length of the axis.
       */
    ;
      stride_t
    my_stride
      /**@brief
       *  Stride of the axis, i.e.
       *  the distance between adjacent
       *  elements on the axis.
       *  If < 0, this indicates the
       *  axis is reversed, IOW for
       *  indices i,j such that i<j:
       *       address of i-th element
       *    >  address of j-th element.
       */
    ;
 public:
      length_t
    length()const
    {
        return my_length;
    }            
      stride_t
    stride()const
    {
        return my_stride;
    }
      stride_t
    size()const
    {
        return length()*abs(stride());
    }          
    length_stride()
    : my_length(1)
    , my_stride(1)
    {}
    length_stride(length_t a_length)
    : my_length(a_length)
    , my_stride(1)
    {}
    length_stride(length_t a_length, stride_t a_stride)
    : my_length(a_length)
    , my_stride(a_stride)
    {}
    
};

}//exit array_stepper namespace
}//exit boost namespace
#endif
