#ifndef BOOST_ARRAY_STEPPER_LENGTH_STRIDE_COMPOSE_HPP_INCLUDED
#define BOOST_ARRAY_STEPPER_LENGTH_STRIDE_COMPOSE_HPP_INCLUDED
#include <boost/array_stepper/length_stride.hpp>
#include <cstddef>
#include <numeric>
namespace boost
{
namespace array_stepper
{
  enum
sign_val
{ less0=-1
, is0
, more0
};

  template
  < typename LengthStride //instance of length_stride.
  , typename Offset=std::size_t
  >
  struct
length_stride_compose
  /**@brief
   *  Used as 1st arg to scan_first_iter to
   *  create LengthStride's from 
   *  sequence of LengthStride::length_t's.
   */
{
        typedef
      LengthStride
    length_stride_t
    ;
        typedef
      typename length_stride_t::length_t
    length_t
    ;
        typedef
      typename length_stride_t::stride_t
    stride_t
    ;
        typedef
      Offset
    offset_t
    ;
 private:    
      offset_t
    my_offset
      /**@brief
       *  Modified by negative length_t arguments.
       *  A negative length_t indicates that the
       *  elements are stored in reverse order.
       *  In other words, the element stored
       *  at index, i, is stored after the 
       *  element stored at index, (i+1).
       *  Here, index means the index argument
       *  to the subscript operator.
       */
    ;
 public:    
    length_stride_compose()
    : my_offset(0)
    {}
      offset_t
    offset()const
    {
        return my_offset;
    }        
    
        static
      sign_val
    isign( length_t a_length)
      /**@brief
       *  Returns one of {less0,is0,more0}
       *  depending on sign of a_length.
       */
    {
        sign_val r=(a_length<0)?less0:((a_length==0)?is0:more0);
        return r;
    }    

      length_stride_t
    operator()
      ( length_t a_length //The first length in the length sequence.
      )
    {
        sign_val sv=isign(a_length);
        length_t ex=abs(a_length);
        stride_t st=1;
        if(sv==less0) my_offset=(ex-1)*st;
        length_stride_t result( ex, sv*st);
        return result;
    }
    
      length_stride_t
    operator()
      ( length_stride_t a_length_stride //previous length stride
      , length_t a_length //current length (not first)
      )
      /**@brief
       *  Returns current length_stride_t.
       */
    {
        sign_val sv=isign(a_length);
        length_t ex=abs(a_length);
        stride_t st=a_length_stride.size();
        if(sv==less0) my_offset+=(ex-1)*st;
        length_stride_t result( ex, sv*st);
        return result;
    }
    
 private:
        static
      offset_t
    plus
      ( offset_t a_offset
      , stride_t a_stride
      )
    {
        return a_offset+a_stride;
    }
        static
      offset_t
    times
      ( length_t a_index
      , length_stride_t const& a_length_stride
      )
    {
        return a_index*a_length_stride.stride();
    }
 public:
      template
      < typename InputIter1
      , typename InputIter2
      >
        static
      offset_t
    offset_at_indices 
      ( InputIter1 first1
      , InputIter1 last1
      , InputIter2 first2
      , offset_t offset0
      )
    {
        return std::inner_product
          ( first1
          , last1
          , first2
          , offset0
          , plus
          , times
          );
    }
         
};

}//exit array_stepper namespace
}//exit boost namespace
#endif
