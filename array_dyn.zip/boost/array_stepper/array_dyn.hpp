#ifndef BOOST_ARRAY_STEPPER_ARRAY_DYN_HPP_INCLUDED
#define BOOST_ARRAY_STEPPER_ARRAY_DYN_HPP_INCLUDED
#include <boost/array_stepper/box_domain.hpp>
#include <iostream>
#include <iomanip>

namespace boost
{
namespace array_stepper
{
  template
  < typename T
  >
  struct  
array_dyn
/**@brief
 *  Multidimensional array whose
 *  'shape' is defined at runtime.
 *  'Shape' means upper bounds on indices
 *  for each dimension (or axis in apl terminology).
 */
: box_domain<>
{
        typedef
      box_domain<>
    super_t
    ;
        typedef
      typename super_t::offset_t
    index_t
    ;
        typedef
      typename super_t::indexs_t
    indexs_t
    ;
      std::vector<T>
    my_data
    /**@brief
     *  data in the array.
     */
    ;
      template
      < typename... Size
      >
    array_dyn( dirs a_dir, Size... a_size)
    : super_t( a_dir, a_size...)
    , my_data
      ( this->super_t::axis_ls
        ( ( a_dir==dir_fwd)
          ? this->super_t::rank()-1
          : 0
        ).size()
      )
    {
    }
    
      T&
    at_indexv( indexs_t const& iv)
    {
        return my_data[offset_at_indexv(iv)];
    }
      T const&
    at_indexv( indexs_t const& iv)const
    {
        return my_data[offset_at_indexv(iv)];
    }
};

  template
  < typename Array
  >
  struct
array_host
{
      Array&
    my_array
    ;
        typedef typename
      Array::index_t
    index_t
    ;
      int const
    my_axis_dir
    /**@brief
     *  +1 or -1: the direction in which axis changes.
     */
    ;
      index_t const
    my_axis_beg
    ;
      index_t const
    my_axis_end
    ;
    array_host
      ( Array& a_array
      , dirs a_dir=dir_fwd
      )
    : my_array(a_array)
    , my_axis_dir
      ( (a_dir==dir_fwd)
      ? +1
      : -1
      )
    , my_axis_beg
      ( (a_dir==dir_fwd)
      ? 0
      : my_array.rank()-1
      )
    , my_axis_end
      ( (a_dir==dir_fwd)
      ? my_array.rank()-1
      : 0
      )
    {
    }
    
      template
      < typename Visitor
      >
      void
    accept
      ( Visitor& a_viz
      )
    {
        accept_off_ax
        ( a_viz
        , my_array.offset()
        , my_axis_beg
        );
    }
 private:
      template
      < typename Visitor
      >
      void
    accept_off_ax
      ( Visitor& a_viz
      , index_t offset
      , index_t axis_now
      )
    {
        index_t const axis_length=my_array.axis_ls(axis_now).length();
        bool const is_leaf=axis_now==my_axis_end;
        index_t const axis_stride=my_array.axis_ls(axis_now).stride();
      #if 0
        std::cout<<std::setw(2*axis_now)<<""
          <<":axis="<<axis_now
          <<":offset="<<offset
          <<":is_leaf="<<is_leaf
          <<":length="<<axis_length
          <<":stride="<<axis_stride
          <<"\n";
      #endif
        for(index_t i=0; i<axis_length; ++i)
        {
          #if 0
            std::cout<<std::setw(1+2*axis_now)<<""
              <<":i="<<i
              <<"\n";
          #endif
            a_viz.visit_pre(is_leaf, axis_now, i);
            if(is_leaf)
            {
                a_viz.visit_node(my_array.my_data[offset]);
            }
            else
            {
                this->accept_off_ax
                  ( a_viz
                  , offset
                  , axis_now+my_axis_dir
                  );
            }
            offset+=axis_stride;
        }
        a_viz.visit_post(is_leaf, axis_now);
    }
};  

  template
  < typename T
  >
  struct
print_array
{
      std::ostream&
    my_sout
    ;
      unsigned const
    my_indent
    ;
        typedef typename
      array_dyn<T>::index_t
    index_t
    ;
    print_array
      ( std::ostream& a_sout
      , unsigned a_indent=2
      )
    : my_sout(a_sout)
    , my_indent(a_indent)
    {}
    
    void visit_pre( bool is_leaf, index_t axis, index_t index)
    {
        if(index==0)
        {
            my_sout<<"{ ";
        }
        else
        {
            if(!is_leaf)
            {
                my_sout<<std::setw(my_indent*axis)<<"";
            }
            my_sout<<", ";
        }
    }
    
    void visit_node(T const& a_t)
    {
        my_sout<<a_t;
    }
        
    void visit_post( bool is_leaf, index_t axis)
    {
        if(!is_leaf)
        {
            my_sout<<std::setw(my_indent*axis)<<"";
        }
        my_sout<<"}\n";
    }
    
};

  template
  < typename T
  >
  std::ostream&
operator<<
( std::ostream& sout
, array_dyn<T>const& a_arr
)
{
    print_array<T> a_viz(sout);
    array_host<array_dyn<T> const> host_arr(a_arr);
    host_arr.accept(a_viz);
    return sout;
}    


}//exit array_stepper namespace
}//exit boost namespace
#endif
