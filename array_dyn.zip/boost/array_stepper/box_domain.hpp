#ifndef BOX_DOMAIN_HPP_INCLUDED
#define BOX_DOMAIN_HPP_INCLUDED
#include <boost/array_stepper/length_stride_compose.hpp>
#include <boost/array_stepper/length_stride.hpp>
#include <boost/array_stepper/scan_first_iter.hpp>
#include <boost/circular_buffer.hpp>

namespace boost
{
namespace array_stepper
{
enum dirs //directions(used to flag order of processing an ordered sequence).
{ dir_fwd //forward direction.
, dir_rev //reverse direction.
};

  template
  < typename LengthType = int
  , typename StrideType = LengthType
  >
  struct
box_domain
  /**@brief
   *  Domain for indices contained within an (hyper)box.
   *  and used to index into (or as the domain of) 
   *  a multidimensional array.
   **@Acknowledgements
   *  Basic idea (and the name) from boost/index_list/domain.hpp
   *  at:
   *    http://svn.boost.org/svn/boost/sandbox/index_list/boost/index_list/domain.hpp
   *  on: 2011-04-23.
   *  
   *  I'm *guessing* that what's missing from this box_domain 
   *  but present in the index_list box_domain are(for I in
   *  0..num_dimensions_-1):
   *    ordering_[I] //Not sure what this is.
   *    ascending_[I] //Not sure what this is.
   *    index_bases_[I] //lower bound for index for I-th axis?
   *    index_tops_[I]  //upper bound for index for I-th axis?
   *  I'm also *guessing* that the my_dirs member variable here
   *  is somehow related to one of:
   *    ordering_
   *    ascending_
   */
{
        typedef
      LengthType
    length_t
    ;
        typedef
      StrideType
    stride_t
    ;
        typedef
      unsigned
    axis_t
    ;
        typedef
      int
    rot_t
      /**@brief
       *  axis rotation amount.
       */
    ;
        typedef
      length_stride<length_t,stride_t>
    length_stride_t
    ;
        typedef
      boost::circular_buffer<length_stride_t>
    length_strides_t
    ;
      length_strides_t
    my_length_strides
    /**@brief
     *  The length & strides for each axis in a multidimensional array.
     */
    ;
        typedef
      length_stride_compose<length_stride_t> 
    comp_t
    ;
        typedef
      typename comp_t::offset_t
    offset_t
    ;
        typedef
      offset_t
    index_t
    ;
        typedef
      std::vector<length_t>
    lengths_t
    ;
        typedef
      std::vector<index_t>
    indexs_t
    ;
 private:    
      offset_t
    my_offset
    /**@brief
     *  Offset from start of array where all 0 index
     *  is located.  my_offset != 0 iff one or more
     *  of the lengths passed to CTOR are < 0.
     */
    ;
      axis_t
    normalize_rotation(int rotation)
    {
        axis_t const rnk=rank();
        int nrot=rotation%rnk;//-rnk < nrot && nrot < rnk
        axis_t mrot=(nrot+rnk)%rnk;//0<=mrot && mrot < rnk
        return mrot;
    }
      template
      < typename InpIter
      , typename OutIter
      >
      void
    init_iter_strides
      ( InpIter lengths_beg
      , InpIter lengths_end
      , OutIter strides_beg
      )
      /**@brief
       *  1) Helper function for init_strides( Lengths...)
       *  2) Initializes my_offset.
       */
    {
        comp_t comp_v;
        scan_first_iter
          ( comp_v
          , lengths_beg
          , lengths_end
          , strides_beg
          );
        my_offset=comp_v.offset();
    }
      void
    init_strides
      ( dirs a_dir
      , lengths_t a_lengths
      )
      /**@brief
       *  1) Calculates strides of the array with shape, a_length...
       *     If(my_dir==dir_fwd) then strides increase with index;
       *     otherwise, they decrease with index.
       *  2) Initializes my_offset.
       */
    {
        if(a_dir==dir_fwd)
        {
            init_iter_strides
              ( a_lengths.begin()
              , a_lengths.end()
              , my_length_strides.begin()
              );
        }
        else
        {
            init_iter_strides
              ( a_lengths.rbegin()
              , a_lengths.rend()
              , my_length_strides.rbegin()
              );
        }
    }
    
        static
     length_stride_t
   default_length_stride()
   {
       length_stride_t v;
       return v;
   }
 public:    
    
    box_domain( dirs a_dir, lengths_t a_lengths)
    : my_length_strides( a_lengths.size(),default_length_stride())
    {
        init_strides(a_dir, a_lengths);
    }
    
      template
      < typename... Length
      >
    box_domain( dirs a_dir, Length... a_length)
    : my_length_strides( sizeof...(Length),default_length_stride())
    {
        init_strides(a_dir, lengths_t({a_length...}));
    }
    
      void
    axis_rot(int a_rot)
    {
        unsigned const n_rot=normalize_rotation(a_rot);
        typedef typename length_strides_t::iterator iter_t;
        iter_t it_rot= my_length_strides.begin()+n_rot;
        my_length_strides.rotate(it_rot);
    }
      axis_t
    rank()const
    {
        return my_length_strides.size();
    }
    
      length_stride_t const&
    axis_ls(axis_t a_axis)const
    {
        return my_length_strides[a_axis];
    }
      offset_t
    offset()const
    {
        return my_offset;
    }
 
      offset_t
    offset_at_indexv
      ( indexs_t const& a_indices
      )const
      /**@brief
       *  The offset of element in an array
       *  corresponding to indices in index vector, a_indicess
       */
    {
        offset_t const offset
          = comp_t::offset_at_indices
            ( a_indices.begin()
            , a_indices.end()
            , my_length_strides.begin()
            , my_offset
            );
        return offset;
    }
    
};

}//exit array_stepper namespace
}//exit boost namespace
#endif
